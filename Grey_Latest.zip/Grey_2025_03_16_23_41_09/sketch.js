//Grey, the zero colour game
var scene = "START";
var help = true;
var dead = false;
var playerSpeed = 4;
var playerSize = 30;
var score = 0;

var quotes = ["Move quickly to go faster",  "You didn't stand a chance", "Press Alt + F4 to dash"];
var quoteSelect = 0;

//display variables
var scaleMod;
var displayCut;
var trueMouseX = 0;
var trueMouseY = 0;

//movement
var movement = function() {
  //controls
  if (keyIsDown(65)) {
    playerX -= playerSpeed
  } else if (keyIsDown(68)) {
    playerX += playerSpeed;
  }
  if (keyIsDown(87)) {
    playerY -= playerSpeed;
  } else if (keyIsDown(83)) {
    playerY += playerSpeed;
  }

  //wall collisions
  if (playerX < 50 + (playerSize / 2) + (playerSize / 10)) {
    dead = true;
  }
  if (playerY < 50 + (playerSize / 2) + (playerSize / 10)) {
    dead = true;
  }
  if (playerX > 550 - (playerSize / 2) - (playerSize / 10)) {
    dead = true;
  }
  if (playerY > 550 - (playerSize / 2) - (playerSize / 10)) {
    dead = true;
  }
};

var playerX = 300;
var playerY = 300;

//border square graphics

//holds all the square values
var Border = [];

//a square object
var bSquare = function() {
  this.x = 0;
  this.y = 0;
  this.shade = 0;
};

//makes a square object
var makeSquare = function(squareX, squareY) {
  var ms = new bSquare(ms);
  ms.x = squareX;
  ms.y = squareY;
  ms.shade = floor(random(2, 5));
  Border.push(ms);
};

//draws the squares
var drawSquare = function() {
  var ds;
  for (ds = 0; ds < Border.length; ds++) {
    push();
    translate(Border[ds].x, Border[ds].y);
    noStroke();
    fill(Border[ds].shade * 60);
    rect(0, 0, 50, 50);
    pop();
  }
};

//food

//holds all the food values
var Foods = [];

//food object
var food = function() {
  this.x = 0;
  this.y = 0;
  this.shade = 0;
};

//makes a food object
var makeFood = function() {
  var mf = new food(mf);
  mf.x = random(100, 500);
  mf.y = random(100, 500);
  mf.shade = floor(random(1, 4));
  Foods.push(mf);
};

//draws the food objects
var drawFood = function() {
  var df;
  for (df = 0; df < Foods.length; df++) {
    push();
    translate(Foods[df].x, Foods[df].y);
    noStroke();
    fill(Foods[df].shade * 50);
    ellipse(0, 0, 20, 20);
    pop();
    if (dist(Foods[df].x, Foods[df].y, playerX, playerY) < (playerSize / 2) + 10) {
      score += Foods[df].shade * 5;
      playerSize += Foods[df].shade / 10;
      playerSpeed += 0.01 * Foods[df].shade;
      Foods.splice(df, 1);
    }
  }
};

//things you have to dodge

//timer
var cooldown = 50;
//type
var atkType = 1;
//if an attack is already in place
var attacking = false;
//the attacks

//attack 1
var atk1X = 0;
var atk1Power = 0;
var atk1 = function() {
  push();
  translate(atk1X, 0);

  //gun graphics
  noStroke();
  fill(255);
  rect(-30, 0, 60, 50);
  strokeWeight(7);
  stroke(0);
  fill(255)
  rect(-20, -10, 40, 70);
  quad(-10, 70, 10, 70, 5, 75, -5, 75);

  //charging animation
  if (atk1Power < 80) {
    for (var atk1C = 0; atk1C < atk1Power / 20; atk1C++) {
      noStroke();
      fill(0);
      rect(-15, atk1C * 15, 30, 8);
    }
  } else {
    for (var atk1C2 = 0; atk1C2 < 4; atk1C2++) {
      noStroke();
      fill(0);
      rect(-15, atk1C2 * 15, 30, 8);
    }
  }

  //shooting
  if (atk1Power > 80) {
    noStroke();
    fill(0);
    rect(-10 - atk1Power / 30, 80, 20 + atk1Power / 15, 999, 5);
    if (dist(playerX, 0, atk1X, 0) < ((atk1Power / 30) + 10) + playerSize / 2) {
      dead = true;
    }
  }
  pop();
  //reseting
  if (atk1Power > 300) {
    attacking = false;
  }

  atk1Power += 1 + score / 200;
};

//attack 2
var atk2timer = 0;
var atk2 = function() {
  //laser
  noStroke();
  fill(0);
  rect(70, 285, atk2timer, 30);
  rect(530, 285, -atk2timer, 30);

  //orb of death
  if (atk2timer > 240) {
    ellipse(300, 300, atk2timer - 220, atk2timer - 220);

    //collisions with orb of death
    if (dist(playerX, playerY, 300, 300) < ((atk2timer - 220) / 2) + playerSize / 2) {
      dead = true;
    }
  }

  //gun stuff
  atk2timer += 1 + score / 200;

  if (atk2timer > 550) {
    attacking = false;
  }

  //gun graphics
  fill(255);
  noStroke();
  rect(0, 250, 50, 100);
  rect(550, 250, 50, 100);
  stroke(0);
  strokeWeight(8);
  rect(-5, 260, 70, 80);
  rect(535, 260, 70, 80);
  if (atk2timer < 0) {
    noStroke();
    fill(0);
    ellipse(30, 300, atk2timer / 2, atk2timer / 2);
    ellipse(570, 300, atk2timer / 2, atk2timer / 2);
  }
};

//attack 3
var atk3timer = 0;
var atk3 = function() {

  //lasers
  if (atk3timer > 0) {
    stroke(0);
    strokeWeight(10 + atk3timer / 10);
    line(0, 0, 600, 600);
    line(0, 600, 600, 0);

    //scary diagonal collisions (well, for me)
    //top left to bottom right
    if (dist(playerX, 0, playerY, 0) < (5 + atk3timer / 20) + playerSize / 1.5) {
      dead = true;
    }
    //bottom left to top right
    if (dist(playerX + playerY, 0, 600, 0) < (5 + atk3timer / 20) + playerSize / 1.5) {
      dead = true;
    }
  }

  //extending laser barrel
  stroke(0);
  strokeWeight(8);
  fill(255);
  if (atk3timer < 0) {
    for (var atk3r = 0; atk3r < 4; atk3r++) {
      push();
      translate(300, 300);
      rectMode(CENTER);
      rotate(45 + atk3r * 90);
      rect(300 - atk3timer / 4, 0, 50, 50);
      rect(285 - atk3timer / 4, 0, 20, 70);

      rectMode(CORNER);
      pop();
    }
  } else {
    for (var atk3r1 = 0; atk3r1 < 4; atk3r1++) {
      push();
      translate(300, 300);
      rectMode(CENTER);
      rotate(45 + atk3r1 * 90);
      rect(300, 0, 50, 50);
      rect(285, 0, 20, 70);
      rectMode(CORNER);
      pop();
    }
  }

  //corner guns
  stroke(0);
  strokeWeight(8);
  fill(255);
  quad(50, 100, 100, 50, 100, -500, -500, 100);
  quad(500, 50, 550, 100, 5000, 100, 500, -500);
  quad(50, 500, 100, 550, 100, 5000, -5000, 500);
  quad(550, 500, 500, 550, 500, 5000, 5000, 500);

  atk3timer += 1 + score / 200;
  //stops the attack after its finished
  if (atk3timer > 200) {
    attacking = false;
  }
};

//menu
var start = function() {
  background(255);
  textAlign(CENTER);
  fill(155);
  noStroke();
  textSize(100);
  text("GRAY", 300, 150);
  textSize(30);
  fill(0);
  text("The zero colour game", 300, 200);

  //button graphics
  fill(155);
  noStroke();
  ellipse(300, 400, 120, 120);
  fill(255);
  textSize(40);
  text("PLAY", 300, 415);

  //button collisions
  if (dist(trueMouseX, trueMouseY, 300, 400) < 60) {
    fill(100);
    noStroke();
    ellipse(300, 400, 120, 120);
    fill(255);
    textSize(40);
    text("PLAY", 300, 415);
  }
  if (mouseIsPressed && dist(trueMouseX, trueMouseY, 300, 400) < 60) {
    scene = "GAME";
  }
};

//lose screen
var end = function() {
  background(255);
  textSize(50);
  textAlign(CENTER);
  fill(0);
  stroke(0);
  strokeWeight(3);
  text("YOU DIED", 300, 150);
  textSize(30);
  strokeWeight(1);
  text("With a score of " + score, 300, 200);

  //home button
  fill(155);
  noStroke();
  ellipse(300, 300, 120, 120);
  fill(255);
  textSize(30);
  text("HOME", 300, 310);

  //button functionaliy
  if (dist(trueMouseX, trueMouseY, 300, 300) < 60) {
    fill(100);
    noStroke();
    ellipse(300, 300, 120, 120);
    fill(255);
    textSize(30);
    text("HOME", 300, 310);
  }
  if (mouseIsPressed && dist(trueMouseX, trueMouseY, 300, 300) < 60) {
    scene = "START";
    cooldown = 100;
    score = 0;
    playerSize = 30;
    playerSpeed = 4;
    dead = false;
    playerX = 300;
    playerY = 300;
    attacking = false;
  }

  //displays the "motivational" quote
  textSize(30);
  noStroke();
  fill(0);
  textAlign(CENTER);

  text(quotes[quoteSelect], 300, 450);

};

//game
var game = function() {
  movement();
  background(255);

  //player graphics
  rectMode(CENTER);
  noFill();
  stroke(0);
  strokeWeight(playerSize / 5);
  rect(playerX, playerY, playerSize, playerSize);
  rectMode(CORNER);

  //I didn't want the player to be a circle but the assignment said that you control a circle so here is a circle you control. You might not be able to see it because its not there. Actually, its there, however, its in a galaxy far far away.
  noFill();
  noStroke();
  //the invisi-cle
  ellipse(99e+99 + playerX, 99e+99 + playerY, 0, 0);

  //draws the squares
  drawSquare();
  drawFood();

  //score
  fill(0);
  stroke(255);
  strokeWeight(5);
  textSize(30);
  textAlign(CENTER);
  text("Score: " + floor(score), 300, 585);


  //starts a new attack once the cooldown is done
  if (cooldown < 0 && attacking === false) {
    atkType = floor(random(1, 4));
    attacking = true;
    atk1X = random(70, 530);
    atk1Power = -100;
    atk2timer = -100;
    atk3timer = -100;
    cooldown = 100;
  }

  //the attacks
  if (attacking === true && atkType === 1) {
    atk1();
  }
  if (attacking === true && atkType === 2) {
    atk2();
  }
  if (attacking === true && atkType === 3) {
    atk3();
  }

  //attack cooldown
  if (attacking === false && help === false) {
    cooldown--;
  }

  //the help (goes away once you move)
  if (help === true) {
    textSize(20);
    fill(0);
    stroke(255);
    strokeWeight(3);
    textAlign(LEFT);
    text("Welcome to Gray, the zero colour game. Move with WASD and eat the dots on the screen. Avoid the wall and the lasers that will be shot at you. The more you eat, the bigger and faster you will be. The higher your score, the faster the attacks are. Good luck! Move to start.", 100, 100, 400, 999);
  }

  if (playerX !== 300 || playerY !== 300) {
    help = false;
  }

  //makes sure there is always 10 food dot thingys
  if (Foods.length < 10) {
    makeFood();
  }

  //if you die
  if (dead === true) {
    scene = "END";
    quoteSelect = floor(random(0, 3));
  }

};

function setup() {

  


  // createCanvas(600, 600);
  createCanvas(windowWidth, windowHeight);

  scaleMod = height / 600;
  displayCut = (width - (height)) / 2;

  //sets all the square positions
  for (var bd = 0; bd < 12; bd++) {
    makeSquare(0, bd * 50);
    makeSquare(550, bd * 50);
    makeSquare(bd * 50, 0);
    makeSquare(bd * 50, 550);
  }
  //turns angle mode to degrees
  angleMode(DEGREES);
}

function draw() {

  //sets the true MouseX
  trueMouseX = (mouseX - displayCut) / scaleMod;
  trueMouseY = mouseY / scaleMod;

  //translates the game so it fits fullscreen and displays it
  push();
  translate(displayCut, 0);
  scale(scaleMod);

  if (scene === "GAME") {
    game();
  }
  if (scene === "START") {
    start();
  }
  if (scene === "END") {
    end();
  }

  pop();

  //blocks out part of the screen
  push();
  rectMode(CORNER);
  noStroke();
  fill(28);
  rect(0, 0, displayCut, height);
  rect(width - displayCut, 0, displayCut, height);
  pop();
}