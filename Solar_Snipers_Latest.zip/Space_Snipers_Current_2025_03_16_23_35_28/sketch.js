//////////////////////////////////////DISPLAY VARIABLES//////////////////////////////////////

var scaleMod;
var displayCut;
var trueMouseX;
var trueMouseY;

//////////////////////////////////////PROGRAM VARIABLES//////////////////////////////////////

var movementKillSensitivity = 0.1;
var maxCollisionCalculations = 50;
var G;
var turn = 1;
var loaded = false;
var fired = false;
var spawned = false;
var fullHp;
var hpLeft;
var hpRight;
var win = 0;
var projectileDmg = 7000;
var gameType = "bot";

//////////////////////////////////////FUNCTIONS//////////////////////////////////////

var vectorLimit = function(vector, limit) {
  var sum = vector.x + vector.y;
  var multiplicitive = limit / sum;
  return createVector(vector.x * multiplicitive, vector.y * multiplicitive);
};
var gradient = function(x, y, clr, reps, startSize, mult1, mult2) {
  noStroke();
  fill(clr);
  for (var i = 0; i < reps; i++) {
    ellipse(x, y, startSize + i * mult1, startSize + i * mult2);
  }
};
var planetMaker = function(x, y, hp, side) {
  for (var j = 0; j < 11; j++) {
    for (var i = 0; i < 360 / (j + 1); i++) {
      stationary.push(new PlanetObj(createVector(x + ((40 - j * 4) * cos(i * (j + 1))), y + ((40 - j * 4) * sin(i * (j + 1)))), 1100, 5, hp, side, true, false, true));
    }
  }
};
var spawnProjectile = function(start, distance, target, type, mouseWait) {


  //calculates the velocity and starting position
  var angle = atan2(target.y - start.y, target.x - start.x);
  var startPoint = createVector(start.x + (distance * cos(angle)), start.y + (distance * sin(angle)));
  var velocity = createVector((target.x - startPoint.x) / 35, (target.y - startPoint.y) / 35);
  if (dist(target.x, target.y, start.x, start.y) < dist(startPoint.x, startPoint.y, start.x, start.y)) {
    velocity.x = 0;
    velocity.y = 0;
  }
  velocity.limit(15);

  //gun graphics
  push();
  translate(startPoint.x, startPoint.y);
  rotate(angle);

  //platform
  noStroke();
  fill(90);
  quad(-8, -4, -8, 4, -4, 2, -4, -2);

  //gray outside border
  noStroke();
  fill(120);
  triangle(-6, -2, -4, -6, 16, -2);
  triangle(-6, 2, -4, 6, 16, 2);

  //power indicator
  strokeWeight(0.7);
  stroke(0, 255, 255);
  if (abs(velocity.x) + abs(velocity.y) > 0) {
    if (abs(velocity.x) + abs(velocity.y) <= 2) {
      line(-6, 2, -6 + (abs(velocity.x) + abs(velocity.y)) * 1.5, 2 + (abs(velocity.x) + abs(velocity.y)) * 2);
      line(-6, -2, -6 + (abs(velocity.x) + abs(velocity.y)) * 1.5, -2 - (abs(velocity.x) + abs(velocity.y)) * 2);
    } else {
      line(-6, 2, -3, 6);
      line(-6, -2, -3, -6);
    }
    if (abs(velocity.x) + abs(velocity.y) > 2 && abs(velocity.x) + abs(velocity.y) <= 12) {
      line(-3, 6, -3 + (abs(velocity.x) + abs(velocity.y) - 2) * 1.8, 6 - (abs(velocity.x) + abs(velocity.y) - 2) * 0.4);
      line(-3, -6, -3 + (abs(velocity.x) + abs(velocity.y) - 2) * 1.8, -6 + (abs(velocity.x) + abs(velocity.y) - 2) * 0.4);
    } else if (abs(velocity.x) + abs(velocity.y) >= 2) {
      line(-3, 6, 15, 2);
      line(-3, -6, 15, -2);
    }
  }

  //dark inside
  noStroke();
  fill(50);
  triangle(-5, -2, -3, -5, 15, -2);
  triangle(-5, 2, -3, 5, 15, 2);

  pop();

  //spawns the projectile  
  if (loaded == true) {


    if (type == 1) {

      if (!mouseIsPressed || mouseWait == false) {
        projectiles.push(new Projectile(createVector(startPoint.x, startPoint.y), createVector(velocity.x, velocity.y), 10, 7, projectileDmg));
        loaded = false;
        fired = true;
      }

    }
  }
  if (fired == true && projectiles.length <= 0) {
    turn++;
    fired = false;
    for (var i = 0; i < stationary.length; i++) {
      if (stationary[i].side == 3) {
        stationary.splice(i, 1);
      }
    }
    spawnAsteroids(10);
  }
};
var spawnAsteroids = function(amount) {
  for (var i = 0; i < amount; i++) {
    stationary.push(new PlanetObj(createVector(random(300, 700), random(100, 400)), random(10, 100), random(10, 100), 1000, 3, true, true, false));
  }
}
var drawHealth = function(x, y, max, current) {
  push();
  translate(x, y);
  noStroke();
  fill(20, 50, 60);
  rect(0, 0, 100, 20, 8)
  fill(0, 70, 209);
  rect(0, 0, 95 * (current / max), 16, 7);
  pop();
}

//////////////////////////////////////BOTS//////////////////////////////////////

var aimX = 0;
var aimY = 0;
var pointX = 500;
var pointY = 250;
var aimed = false;
var shot = false;
var aiming = function(){
  if(aimX > pointX){
    pointX += abs(aimX - pointX)/30 + 1;
  }else if(aimX < pointX){
    pointX -= abs(aimX - pointX)/30 + 1;
  }
  
  if(aimY > pointY){
    pointY += abs(aimY - pointY)/30 + 1;
  }else if(aimY < pointY){
    pointY -= abs(aimY - pointY)/30 + 1;
  }
  
}

//the crappy bot
var bot1 = function(side) {
  if (turn == side && projectiles.length <= 0) {
      if(aimed == false && shot == false){
        aimX = random(200,800);
        aimY = random(100,400);
        aimed = true;
      }
      
      if(dist(aimX,aimY,pointX,pointY)>2){
        aiming();
      }
      
      if (frameCount % 100 == 0 && aimed == true) {
        loaded = true;
        shot = true;
        aimed = false;
      }
      if(side == 1){
        projectileDmg = 14000;//double it to make it harder for the player
        spawnProjectile(createVector(100, 250), 50, createVector(pointX, pointY), 1, false);
        projectileDmg = 7000;
      }
      else if(side == 2){
        projectileDmg = 14000;
        spawnProjectile(createVector(900, 250), 50, createVector(pointX, pointY), 1, false);
        projectileDmg = 7000;
      }
      shot = false;
  }
};





//////////////////////////////////////DEBUGGING VARIABLES//////////////////////////////////////

var frames = 0;

//////////////////////////////////////CLASSES//////////////////////////////////////

class PlanetObj {
  constructor(position, density, size, hp, side, destructable, show, makeHole, real) {
    this.position = position;
    this.density = density;
    this.size = size;
    this.gravity = 0;
    this.gravVect = 0;
    this.hp = hp;
    this.mass = (4 / 3) * pow(size / 2, 3) * 3.14159265 * density;
    this.side = side;
    this.destructable = destructable;
    this.show = show;
    this.makeHole = makeHole;
    this.real = real;
  }

  display() {
    if (this.show == true) {
      noStroke();
      fill(100 - this.density);
      ellipse(this.position.x, this.position.y, this.size);
    }
  }

  collision() {
    for (var i = 0; i < projectiles.length; i++) {
      if (dist(this.position.x, this.position.y, projectiles[i].position.x, projectiles[i].position.y) <= (this.size + projectiles[i].size) / 2) {
        if (projectiles[i].position.x > this.position.x) {
          projectiles[i].position.x += (this.size / 2) + (projectiles[i].size / 2) - dist(this.position.x, this.position.y, projectiles[i].position.x, projectiles[i].position.y);
        }
        if (projectiles[i].position.x < this.position.x) {
          projectiles[i].position.x -= (this.size / 2) + (projectiles[i].size / 2) - dist(this.position.x, this.position.y, projectiles[i].position.x, projectiles[i].position.y);
        }
        if (projectiles[i].position.y > this.position.y) {
          projectiles[i].position.y += (this.size / 2) + (projectiles[i].size / 2) - dist(this.position.x, this.position.y, projectiles[i].position.x, projectiles[i].position.y);
        }
        if (projectiles[i].position.y < this.position.y) {
          projectiles[i].position.y -= (this.size / 2) + (projectiles[i].size / 2) - dist(this.position.x, this.position.y, projectiles[i].position.x, projectiles[i].position.y);
        }
      }
    }
  }

  update() {
    if (this.side !== turn || this.side == 3) {
      for (var i = 0; i < projectiles.length; i++) {

        //finds the gravatational pull
        this.gravity = G * ((this.mass * projectiles[i].mass) / pow(dist(this.position.x, this.position.y, projectiles[i].position.x, projectiles[i].position.y), 2));

        //turns it into a vector
        this.gravVect = createVector(dist(this.position.x, 0, projectiles[i].position.x, 0), dist(0, this.position.y, 0, projectiles[i].position.y));
        this.gravVect = vectorLimit(this.gravVect, 1);
        this.gravVect.mult(this.gravity);

        //applies the gravity
        if (this.position.x > projectiles[i].position.x) {
          projectiles[i].vel.x += this.gravVect.x;
        } else if (this.position.x < projectiles[i].position.x) {
          projectiles[i].vel.x -= this.gravVect.x;
        }
        if (this.position.y > projectiles[i].position.y) {
          projectiles[i].vel.y += this.gravVect.y;
        } else if (this.position.y < projectiles[i].position.y) {
          projectiles[i].vel.y -= this.gravVect.y;
        }
      }
    }
  }
}
class Projectile {
  constructor(position, vel, density, size, hp, real) {
    this.MPF = 1;
    this.position = position;
    this.density = density;
    this.vel = vel;
    this.size = size;
    this.pX = this.position.x;
    this.pY = this.position.y;
    this.mass = (4 / 3) * pow(size / 2, 3) * 3.14159265 * this.density;
    this.hp = hp;
    this.rotate = 0;
    this.real = real;
  }

  display() {
    push();
    translate(this.position.x, this.position.y);
    rotate(this.rotate);
    noStroke();
    fill(0, 255, 255, 30);
    for (var i = 0; i < 10; i++) {
      rect(0, 0, this.size / 4, this.size / (2.5 + i / 2));
    }
    for (var j = 0; j < 20; j++) {
      fill(70 + j * 5);
      triangle(0, this.size / (3 + j / 10), 0, -this.size / (3 + j / 10), this.size * (2 - j / 10), 0);
      triangle(-this.size / 8, this.size / (3 + j / 10), -this.size / 8, -this.size / (3 + j / 10), -this.size / (3 + j / 10), 0)
    }
    pop();
  }

  update() {
    //collisions
    for (var i = 0; i < stationary.length; i++) {
      if (stationary[i].side !== turn && abs(stationary[i].position.x - (this.position.x)) <= abs(this.vel.x) || stationary[i].side == 3 && abs(stationary[i].position.x - (this.position.x)) <= abs(this.vel.x)) {
        this.MPF = ceil(dist(this.vel.x, this.vel.y, 0, 0)) / 2;
        if (this.MPF > maxCollisionCalculations) {
          this.MPF = maxCollisionCalculations;
        }
        break;
      } else {
        this.MPF = 1;
      }
    }
    this.pX = this.position.x;
    this.pY = this.position.y;

    for (var j = 0; j < this.MPF; j++) {
      this.position.x += this.vel.x / this.MPF;
      this.position.y += this.vel.y / this.MPF;
      for (var k = 0; k < stationary.length; k++) {
        if (stationary[k].side !== turn || stationary[k].side == 3) {
          stationary[k].collision();
        }
      }
    }
    this.MPF = 1;

    //calculates the rotation
    this.rotate = atan2(this.vel.y, this.vel.x);

  }

  destroy() {
    for (var i = 0; i < stationary.length; i++) {
      if (stationary[i].destructable == true && stationary[i].side !== turn && dist(stationary[i].position.x, stationary[i].position.y, this.position.x, this.position.y) < (this.size + stationary[i].size) / 2 + 15 || stationary[i].destructable == true && stationary[i].side == 3 && dist(stationary[i].position.x, stationary[i].position.y, this.position.x, this.position.y) < (this.size + stationary[i].size) / 2 + 5) {
        if (stationary[i].hp <= this.hp) {
          this.hp -= stationary[i].hp;
          stationary[i].hp = 0;
        } else {
          stationary[i].hp -= this.hp;
          this.hp = 0;
        }
        if (this.hp <= 0) {
          break;
        }
      } else if (dist(stationary[i].position.x, stationary[i].position.y, this.position.x, this.position.y) < (this.size + stationary[i].size) / 2) {
        this.hp = 0;
        break;
      }
    }
  }
}
class Hole {
  constructor(position, size, clr) {
    this.position = position;
    this.size = size;
    this.clr = clr;
  }

  display() {
    noStroke();
    fill(this.clr);
    ellipse(this.position.x, this.position.y, this.size);
  }
}

//////////////////////////////////////ARRAYS//////////////////////////////////////

//game arrays
var stationary = [];
var projectiles = [];
var holes = [];
var planetGrad1 = [];
var planetGrad2 = [];

//menu arrays
var gasClouds = [];
var stars = [];
var asteroids = [];

//////////////////////////////////////SCENES//////////////////////////////////////

var scene = "menu";
var menu = function() {
  background(0, 30, 40);

  //planet background
  noStroke();
  fill(255, 213, 140, 5);
  for (var j = 0; j < 30; j++) {
    ellipse(180, 180, 400 - j);
  }

  //draws the patterns on the planet
  for (var k = 0; k < gasClouds.length / 3; k++) {
    gradient(gasClouds[k * 3], gasClouds[k * 3 + 1], gasClouds[k * 3 + 2], 15, 50, 20, 8);
  }

  //adding shadows on the planet
  // push();
  // noFill();
  // strokeWeight(16);
  // translate(180, 180);
  // rotate(-110);
  // // for (var m = 0; m < 100; m++) {
  // //   stroke(0, 30, 40, 10 + m);
  // //   arc(0, 0, 400, 400 - m * 4, 0, 180);
  // //   stroke(0, 30, 40, 110 + m)
  // //   arc(0, 0, 400, 0 + m * 4, 180, 0);
  // // }
  // noStroke();
  // // for (var n = 0; n < 51; n++) {
  // //   fill(0, 30, 40, 127 - n / 2);
  // //   rect(-202 + n * 4, 0, 4, 4);
  // //   rect(202 - n * 4, 0, 4, 4);
  // // }
  // pop();

  fill(0, 30, 40, 10);
  for(var m = 0; m < 25; ++m){
    ellipse(180 - m * 5,180,400 + m * 5,400 + m * 5);
  }
  //wrap around the planet
  noFill();
  strokeWeight(100);
  stroke(0, 30, 40);
  ellipse(180, 180, 500);

  //stars
  // noStroke();
  stroke(255,255,255);
  strokeWeight(1);
  for (var i = 0; i < stars.length / 2; i++) {
    point(stars[i * 2], stars[i * 2 + 1]);
    // gradient(stars[i * 3], stars[i * 3 + 1], color(255, 255, 255, 30), stars[i * 3 + 2], 1, 1, 1);
  }
  //moon/play button graphics
  noStroke();
  for (var o = 0; o < 15; o++) {
    fill(40 + o * 2);
    ellipse(400 + o, 250 - o, 80 - o * 4);
  }
  fill(100);
  textSize(20);
  text("PLAY", 400, 255)

  //play button functionality
  if (dist(400, 250, trueMouseX, trueMouseY) < 40) {
    push();
    translate(400, 250);
    rotate(frameCount);
    noFill();
    strokeWeight(5);
    stroke(200, 0, 0);
    ellipse(0, 0, 100);
    noStroke();
    fill(200, 0, 0);
    rect(50, 0, 30, 5);
    rect(0, 50, 5, 30);
    rect(-50, 0, 30, 5);
    rect(0, -50, 5, 30);
    ellipse(0, 0, 5, 5);
    pop();
    if (mouseIsPressed) {
      scene = "game";
    }
  }

  //title
  fill(150);
  textSize(70);
  text("Solar Snipers", 500, 100)

  //delete after
  // noStroke();
  // textSize(20);
  // fill(255);
  // frames += frameRate();
  // textSize(20);
  // text("average frameRate: " + round(frames / frameCount), 110, 20);
  // text("current frameRate: " + round(frameRate()), 100, 40);
};
var game = function() {
  background(0, 30, 40);

  //planet 1 graphics
  noStroke();
  fill(200, 100, 100, 100);
  ellipse(100, 250, 85, 85);
  for (var i = 0; i < planetGrad1.length / 3; i++) {
    gradient(planetGrad1[i * 3], planetGrad1[i * 3 + 1], planetGrad1[i * 3 + 2], 15, 15, 8, 2);
  }

  //adding shadows on the planet
  push();
  noFill();
  strokeWeight(4);
  translate(100, 250);
  rotate(-110);
  for (var m = 0; m < 22; m++) {
    stroke(0, 30, 40, 10 + m * 2);
    arc(0, 0, 85, 85 - m * 4, 0, 180);
    stroke(0, 30, 40, 54 + m * 2)
    arc(0, 0, 85, m * 4.1, 180, 0);
  }
  pop();

  //wrap
  noFill();
  strokeWeight(50);
  stroke(0, 30, 40);
  ellipse(100, 250, 135, 135);

  //planet 2 graphics
  noStroke();
  fill(100, 200, 200, 100);
  ellipse(900, 250, 85, 85);
  for (var p = 0; p < planetGrad2.length / 3; p++) {
    gradient(planetGrad2[p * 3], planetGrad2[p * 3 + 1], planetGrad2[p * 3 + 2], 15, 15, 8, 2);
  }

  //adding shadows on the planet
  push();
  noFill();
  strokeWeight(4);
  translate(900, 250);
  rotate(-110);
  for (var q = 0; q < 22; q++) {
    stroke(0, 30, 40, 10 + q * 2);
    arc(0, 0, 85, 85 - q * 4, 0, 180);
    stroke(0, 30, 40, 54 + q * 2)
    arc(0, 0, 85, q * 4.1, 180, 0);
  }
  pop();

  //wrap
  noFill();
  strokeWeight(50);
  stroke(0, 30, 40);
  ellipse(900, 250, 135, 135);




  //aiming and shooting
  if (turn == 1) {
    
  // if (mouseIsPressed && fired == false) {
  //   loaded = true;
  // }
  //   spawnProjectile(createVector(100, 250), 50, createVector(trueMouseX, trueMouseY), 1);
  

  } else if (turn == 2) {
    if (mouseIsPressed && fired == false) {
      loaded = true;
    }
    spawnProjectile(createVector(900, 250), 50, createVector(trueMouseX, trueMouseY), 1, true);
  }
  
  bot1(1);

  //makes sure the turn is 1 or 2
  if (turn > 2) {
    turn = 1;
  }

  //updates the gravity and collisions and displays the objects
  for (var k = 0; k < stationary.length; k++) {
    stationary[k].display();
    stationary[k].update();
  }

  //makes the holes in the planet
  for (var o = 0; o < holes.length; o++) {
    holes[o].display();
  }

  //updates the projectiles and displays them
  for (var j = 0; j < projectiles.length; j++) {
    projectiles[j].display();
    projectiles[j].update();
    projectiles[j].destroy();
  }



  //removes projectiles that have no hp or went off the screen
  for (var l = 0; l < projectiles.length; l++) {
    if (projectiles[l].hp <= 0 || projectiles[l].position.x < 0 || projectiles[l].position.x > 1000 || projectiles[l].position.y < 0 || projectiles[l].position.y > 500) {
      projectiles.splice(l, 1);
    }
  }

  //removes planet objects that have no hp
  for (var n = 0; n < stationary.length; n++) {
    if (stationary[n].hp <= 0) {
      if (stationary[n].makeHole == true) {
        holes.push(new Hole(stationary[n].position, stationary[n].size + random(0, 3), color(0, 30, 40)));
      }
      stationary.splice(n, 1);
    }
  }

  //calculates the amount of hp each side has
  for (var r = 0; r < stationary.length; r++) {
    if (stationary[r].side == 1) {
      hpLeft++;
    } else if (stationary[r].side == 2) {
      hpRight++;
    }
  }
  drawHealth(100, 160, fullHp, hpLeft);
  drawHealth(900, 160, fullHp, hpRight);

  //detects if someone wins
  if (hpLeft / fullHp < 0.1) {
    win = 2;
  } else if (hpRight / fullHp < 0.1) {
    win = 1;
  }

  if (win !== 0) {
    scene = "end";
  }

  hpLeft = 0;
  hpRight = 0;

  //delete after
  // noStroke();
  // textSize(20);
  // fill(255);
  // frames += frameRate();
  // textSize(20);
  // text("average frameRate: " + round(frames / frameCount), 110, 20);
  // text("current frameRate: " + round(frameRate()), 100, 40);
};
var end = function() {
  background(0, 30, 40);
  noStroke();
  fill(255);
  textSize(100);
  if (win == 1) {
    text("The left side won!", 500, 250);
  } else if (win == 2) {
    text("The right side won!", 500, 250);
  }

  //delete after
  noStroke();
  textSize(20);
  fill(255);
  frames += frameRate();
  textSize(20);
  text("average frameRate: " + round(frames / frameCount), 110, 20);
  text("current frameRate: " + round(frameRate()), 100, 40);
};

//////////////////////////////////////SETUP//////////////////////////////////////

function setup() {

  //GAME VARIABLES//

  //setting up the gravitational constant
  G = 6.6740e-8;

  //setting angle to degrees
  angleMode(DEGREES);

  //setting rectmode
  rectMode(CENTER);

  //setting the text align
  textAlign(CENTER);

  //creating the canvas
  createCanvas(windowWidth, windowHeight);
  //createCanvas(1000, 500);

  //sets the scale modifier
  scaleMod = width / 1000;
  displayCut = (height - (width / 2)) / 2;

  //sets the seed
  //randomSeed(10);

  //makes the planets
  planetMaker(100, 250, 100, 1);
  planetMaker(900, 250, 100, 2);

  //sets the hp
  fullHp = stationary.length / 2;
  hpLeft = fullHp;
  hpRight = fullHp;

  //spawns the asteroids (delete after)
  spawnAsteroids(10);

  //makes the graphics for the planets
  for (var i = 0; i < 5; i++) {
    planetGrad1.push(random(75, 125));
    planetGrad1.push(random(225, 275));
    planetGrad1.push(color(random(230, 255), random(130, 164), random(56, 66), random(2, 4)));
  }

  for (var j = 0; j < 5; j++) {
    planetGrad2.push(random(875, 925));
    planetGrad2.push(random(225, 275));
    planetGrad2.push(color(random(0, 20), random(190, 210), random(210, 230), random(2, 4)));
  }

  //MENU VARIABLES//

  //creates the patterns on the planet
  for (var k = 0; k < 3; k++) {
    gasClouds.push(random(50, 300));
    gasClouds.push(random(50, 300));
    gasClouds.push(color(random(230, 255), random(130, 164), random(50, 66), random(4, 7)));
  }


  //makes the stars
  for (var m = 0; m < 200; m++) {
    stars.push(random(0, 1000));
    stars.push(random(0, 500));
  }


  //removes some stars that are too close to the planet
    for (var n = stars.length/2-1; n >= 0; n--) {
      if (stars[n *2] < 380 && stars[n * 2 + 1] < 380) {
        stars.splice(n * 2 - 1, 2);
      }
    }
}

//////////////////////////////////////DRAW//////////////////////////////////////

function draw() {

  //sets the true trueMouseX
  trueMouseX = mouseX / scaleMod
  trueMouseY = (mouseY - displayCut) / scaleMod

  //translates the game so it fits fullscreen and displays it
  push();
  translate(0, displayCut);
  scale(scaleMod);

  if (scene == "menu") {
    menu();
  } else if (scene == "game") {
    game();
  } else if (scene == "end") {
    end();
  }

  pop();

  //blocks out part of the screen
  push();
  rectMode(CORNER);
  noStroke();
  fill(28);
  rect(0, 0, width, displayCut);
  rect(0, height - displayCut, width, displayCut);
  pop();
}

//hello there