//game variables
var baseMaxHp = 1000;
var baseHp = baseMaxHp;
var pause = false;
var scene = "START";
var keyDown = false
var money = 100;
var timer = 200;
var spawn1 = 0.5;
var spawn2 = 1;
var score = 0;

//display variables
var scaleMod;
var displayCut;
var trueMouseX = 0;
var trueMouseY = 0;

//code bullet
var bulletSpeed = 10;
var bulletDmg = 1;
var bulletSize = 10;
var Bullets = [];
var bullet = function() {
  this.x = 0;
  this.y = 0;
  this.h = 0;
  this.v = 0;
  this.hp = 0;
  this.dmg = 0;
  this.rot = 0;
  this.clr = 0;
  this.target = 0;
  this.startPointX = 0;
  this.startPointY = 0;
  this.explode = false;
  this.boomSize = 0;
};
var makeBullet = function(positionX, positionY, rot, startX, startY, bulletClr, accuracy, targetX, targetY, speed, dmg) {
  var bulletTraits = new bullet(bulletTraits);
  bulletTraits.x = (startY * sin(-rot) + startX * cos(-rot)) + positionX;
  bulletTraits.y = (startY * cos(-rot) - startX * sin(-rot)) + positionY;
  bulletTraits.h = sin(rot + 90) * speed + random(-accuracy, accuracy);
  bulletTraits.v = -cos(rot + 90) * speed + random(-accuracy, accuracy);
  bulletTraits.hp = 1;
  bulletTraits.dmg = dmg;
  bulletTraits.rot = rot;
  bulletTraits.clr = bulletClr;
  bulletTraits.target = dist(targetX, targetY, positionX + startX, positionY + startY) + random(-50, 50);
  bulletTraits.startPointX = positionX + startX;
  bulletTraits.startPointY = positionY + startY;
  bulletTraits.explode = false;
  Bullets.push(bulletTraits);
};
var drawBullet = function() {
  for (var i = 0; i < Bullets.length; i++) {
    //graphics
    if (Bullets[i].hp > 0) {
      push();
      translate(Bullets[i].x, Bullets[i].y);
      rotate(Bullets[i].rot);
      noStroke();
      for (var i2 = 0; i2 < bulletSize / 2; i2++) {
        fill(Bullets[i].clr);
        ellipse(0, 0, i2 * 4, i2);
      }
      pop();

      if (pause == false) {
        //movement
        Bullets[i].x += Bullets[i].h;
        Bullets[i].y += Bullets[i].v;
      }
    }

    //if the bullet reaches the target (your mouse)
    if (dist(Bullets[i].x, Bullets[i].y, Bullets[i].startPointX, Bullets[i].startPointY) >= Bullets[i].target) {
      Bullets[i].hp = 0;
    }

    //enemy detection
    for (var i3 = 0; i3 < Enemies.length; i3++) {

      //if it gets close to an enemy
      if (dist(Bullets[i].x, Bullets[i].y, Enemies[i3].x, Enemies[i3].y) < Enemies[i3].size / 2 && Enemies[i3].hp > 0) {
        Bullets[i].hp = 0;
      }

      //damages enemies that are in the explosion
      if (dist(Bullets[i].x, Bullets[i].y, Enemies[i3].x, Enemies[i3].y) < Enemies[i3].size + Bullets[i].boomSize / 2 && pause == false) {
        Enemies[i3].hp -= Bullets[i].dmg;
      }

    }

    //explodes if the damage zero
    if (Bullets[i].hp <= 0) {
      fill(0, 255, 255, 150);
      if (pause == false) {
        Bullets[i].boomSize += 2;
      }
      noStroke();
      ellipse(Bullets[i].x, Bullets[i].y, Bullets[i].boomSize);

      if (Bullets[i].boomSize > 30) {
        Bullets[i].explode = true;
      }
    }

  }
};

//enemy code
var Enemies = [];
var enemy = function() {
  this.x = 0;
  this.y = 0;
  this.maxHp = 0;
  this.hp = 0;
  this.speed = 0;
  this.size = 0;
  this.dmg = 0;
  this.explode = false;
  this.boomSize = 0;
  this.type = 0;
};
var makeEnemy = function(type) {
  var enemyTraits = new enemy(enemyTraits);
  //sets the enemy's stats
  enemyTraits.x = random(-150, -50);
  enemyTraits.y = random(50, 650);
  enemyTraits.type = type;

  //sets the stats
  if (enemyTraits.type == 1) {
    enemyTraits.maxHp = 150;
    enemyTraits.speed = 1;
    enemyTraits.size = 50;
    enemyTraits.dmg = 0.4;
  }

  if (enemyTraits.type == 2) {
    enemyTraits.maxHp = 100;
    enemyTraits.speed = 3;
    enemyTraits.size = 50;
    enemyTraits.dmg = 0.5;
  }

  if (enemyTraits.type == 3) {
    enemyTraits.maxHp = 1000;
    enemyTraits.speed = 0.5;
    enemyTraits.size = 50;
    enemyTraits.dmg = 3;
  }

  if (enemyTraits.type == 4) {
    enemyTraits.maxHp = 400;
    enemyTraits.speed = 1.5;
    enemyTraits.size = 50;
    enemyTraits.dmg = 2;
  }

  if (enemyTraits.type == 5) {
    enemyTraits.maxHp = 300;
    enemyTraits.speed = 3.5;
    enemyTraits.size = 60;
    enemyTraits.dmg = 1.5;
  }

  if (enemyTraits.type == 6) {
    enemyTraits.maxHp = 3000;
    enemyTraits.speed = 0.5;
    enemyTraits.size = 70;
    enemyTraits.dmg = 4;
  }

  if (enemyTraits.type == 7) {
    enemyTraits.maxHp = 1000;
    enemyTraits.speed = 2;
    enemyTraits.size = 80;
    enemyTraits.dmg = 8;
  }

  if (enemyTraits.type == 8) {
    enemyTraits.maxHp = 20000;
    enemyTraits.speed = 0.8;
    enemyTraits.size = 80;
    enemyTraits.dmg = 15;
  }


  //static variables
  enemyTraits.hp = enemyTraits.maxHp;
  enemyTraits.boomSize = 0;
  enemyTraits.explode = false;
  Enemies.push(enemyTraits);
};
var drawEnemy = function() {

  for (var i = 0; i < Enemies.length; i++) {

    if (Enemies[i].hp > 0) {
      //graphics
      push();
      translate(Enemies[i].x, Enemies[i].y);

      if (Enemies[i].type == 1) {

        //missile 1 graphics
        noStroke();
        fill(0);
        quad(-30, 0, -35, -10, 0, 0, -35, 10);
        fill(100);
        arc(0, 0, 20, 10, 270, 90);
        rect(-15, 0, 40, 10, 4);

        //flame graphics
        fill(255, 153, 0, 80);
        for (var i2 = 0; i2 < 5; i2++) {
          arc(-35, 0, random(-20, 20) + 50 - i2 * 5, random(-2, 2) + 10 - i2, 90, 270);
        }
      }

      if (Enemies[i].type == 2) {

        //missile 2 graphics
        noStroke();
        fill(255, 0, 0);
        quad(-25, 0, -35, -10, -40, -10, -38, 0);
        quad(-25, 0, -35, 10, -40, 10, -38, 0);
        fill(200);
        rect(-20, 0, 40, 6);
        fill(250);
        arc(0, 0, 50, 10, 270, 90);
        quad(0.5, -5, 0.5, 5, -5, 3, -5, -3);

        //flame graphics
        fill(255, 153, 0, 80);
        for (var i3 = 0; i3 < 5; i3++) {
          arc(-40, 0, random(-20, 20) + 100 - i3 * 5, random(-2, 2) + 10 - i3, 90, 270);
        }
      }

      if (Enemies[i].type == 3) {

        //missile 3 graphics
        noStroke();
        fill(150);
        quad(0, 0, -30, -20, -25, 0, -30, 20);
        fill(0, 174, 255);
        arc(0, 8, 50, 40, 270, 340);
        arc(0, -8, 50, 40, 20, 90);
        fill(200);
        quad(0, 12, 0, -12, -30, -4, -30, 4);

        //flame graphics
        fill(255, 153, 0, 80);
        for (var i4 = 0; i4 < 5; i4++) {
          arc(-30, 0, random(-20, 20) + 50 - i4 * 5, random(-2, 2) + 8 - i4, 90, 270);
        }
      }

      if (Enemies[i].type == 4) {

        //missile 4 graphics
        noStroke();
        fill(80);
        quad(-10, 0, -40, -10, -35, 0, -40, 10);
        fill(100);
        arc(0, 0, 40, 8, 270, 90);
        quad(0, -4, 0, 4, -40, 2, -40, -2);
        fill(0, 200, 0);
        rect(0, 0, 3, 8);

        //flame graphics
        fill(255, 153, 0, 80);
        for (var i5 = 0; i5 < 5; i5++) {
          arc(-40, 0, random(-20, 20) + 150 - i5 * 5, random(-2, 2) + 4 - i5, 90, 270);
        }
      }

      if (Enemies[i].type == 5) {
        //missile 5 graphics
        noStroke();
        fill(255, 0, 0);
        triangle(-5, -10, -5, 10, 5, 0);
        triangle(-75, -20, -75, 20, -65, 0);
        fill(250);
        rect(-40, 0, 80, 6);
        arc(0, 0, 50, 6, 270, 90);

        //flame graphics
        fill(255, 153, 0, 80);
        for (var i6 = 0; i6 < 5; i6++) {
          arc(-80, 0, random(-20, 20) + 150 - i6 * 5, random(-2, 2) + 6 - i6, 90, 270);
        }
      }

      if (Enemies[i].type == 6) {

        //missile 6 graphics
        noStroke();
        fill(255, 0, 0);
        rect(-100, 0, 20, 50);
        fill(200);
        arc(10, 0, 30, 30, 270, 90);
        rect(-39, 0, 100, 30);
        quad(-88, -15, -88, 15, -115, 5, -115, -5);

        //flame graphics
        fill(255, 153, 0, 80);
        for (var i7 = 0; i7 < 5; i7++) {
          arc(-115, 0, random(-20, 20) + 100 - i7 * 5, random(-2, 2) + 10 - i7, 90, 270);
        }
      }

      if (Enemies[i].type == 7) {

        //missile 7 graphics
        noStroke();
        fill(130);
        quad(-30, -20, -30, 20, 40, 5, 40, -5);
        fill(100);
        quad(20, -10, 20, 10, 42, 4, 42, -4);
        ellipse(42, 0, 10, 8);
        quad(-30, -20, -30, 20, -35, 15, -35, -15);
        fill(80);
        quad(-35, 15, -35, -15, -42, -18, -42, 18);

        //air graphics
        for (var i8 = 0; i8 < 10; i8++) {
          strokeWeight(4);
          stroke(255, 20);
          noFill();
          arc(-50, 0, 200, random(-50, 50), 270 + random(-20, 20), 90 + random(-20, 20));
        }
      }

      if (Enemies[i].type == 8) {

        //missile 8 graphics

        //flame graphics
        fill(0, 255, 255, 80);
        for (var i9 = 0; i9 < 5; i9++) {
          arc(-30, 4, random(-20, 20) + 100 - i9 * 5, random(-2, 2) + 6 - i9, 90, 270);
          arc(-30, -4, random(-20, 20) + 100 - i9 * 5, random(-2, 2) + 6 - i9, 90, 270);
        }
        noStroke();
        fill(70);
        triangle(35, 0, -20, -20, -30, 0);
        triangle(35, 0, -20, 20, -30, 0);
        strokeWeight(2);
        stroke(0, 255, 255);
        line(35, 0, -19, -19);
        line(35, 0, -19, 19);
        noStroke();
        fill(50);
        quad(40, 0, -35, -10, -40, 0, -35, 10);
      }
      pop();

      //movement
      if (pause == false) {
        Enemies[i].x += Enemies[i].speed;
      }
    }

    //functionality
    if (Enemies[i].x >= 530 && pause == false) {
      Enemies[i].hp = 0;
      baseHp -= Enemies[i].dmg
    }

    //exploding
    if (Enemies[i].hp <= 0) {
      noStroke();
      fill(255, 120, 0, 100);
      ellipse(Enemies[i].x, Enemies[i].y, Enemies[i].boomSize);
      if (pause == false) {
        Enemies[i].boomSize += Enemies[i].dmg * 10;
      }
      if (Enemies[i].boomSize / 500 >= Enemies[i].dmg) {
        Enemies[i].explode = true;
      }

    }



  }
};

//turret code
var Turrets = [];
var turret = function() {
  this.x = 0;
  this.y = 0;
  this.size = 0;
  this.range = 0;
  this.dmg = 0;
  this.rot = 0;
  this.reload = 0;
  this.reloadTimer = 0;
  this.accuracy = 0;
  this.speed = 0;
  this.shotAmount = 0;
  this.locked = 0;
  this.shotX = 0;
  this.shotY = 0;
};
var makeTurret = function(type, x, y) {
  var turretTraits = new turret(turretTraits);
  turretTraits.x = x;
  turretTraits.y = y;
  turretTraits.type = type;

  //turret 1 stats
  if (turretTraits.type == 1) {
    turretTraits.size = 20;
    turretTraits.dmg = 0.3;
    turretTraits.accuracy = 1;
    turretTraits.reload = 5;
    turretTraits.speed = 10;
    turretTraits.range = 400;
    turretTraits.shotAmount = 1;
    turretTraits.shotX = 9;
    turretTraits.shotY = -5;
  }

  //turret 2 stats
  if (turretTraits.type == 2) {
    turretTraits.size = 20;
    turretTraits.dmg = 0.3;
    turretTraits.accuracy = 2;
    turretTraits.reload = 25;
    turretTraits.speed = 10;
    turretTraits.range = 200;
    turretTraits.shotAmount = 10;
    turretTraits.shotX = 9;
    turretTraits.shotY = -5;
  }

  //turret 3 stats
  if (turretTraits.type == 3) {
    turretTraits.size = 20;
    turretTraits.dmg = 3;
    turretTraits.accuracy = 0.1;
    turretTraits.reload = 40;
    turretTraits.speed = 15;
    turretTraits.range = 700;
    turretTraits.shotAmount = 1;
    turretTraits.shotX = 9;
    turretTraits.shotY = -5;
  }

  //turret 4 stats
  if (turretTraits.type == 4) {
    turretTraits.size = 20;
    turretTraits.dmg = 1;
    turretTraits.accuracy = 1;
    turretTraits.reload = 15;
    turretTraits.speed = 10;
    turretTraits.range = 600;
    turretTraits.shotAmount = 1;
    turretTraits.shotX = 9;
    turretTraits.shotY = -5;
  }

  //turret 5 stats
  if (turretTraits.type == 5) {
    turretTraits.size = 20;
    turretTraits.dmg = 0.5;
    turretTraits.accuracy = 2;
    turretTraits.reload = 2;
    turretTraits.speed = 30;
    turretTraits.range = 550;
    turretTraits.shotAmount = 1;
    turretTraits.shotX = 9;
    turretTraits.shotY = -3.5;
  }

  //turret 6 stats
  if (turretTraits.type == 6) {
    turretTraits.size = 20;
    turretTraits.dmg = 150;
    turretTraits.accuracy = 0.05;
    turretTraits.reload = 500;
    turretTraits.speed = 40;
    turretTraits.range = 900;
    turretTraits.shotAmount = 1;
    turretTraits.shotX = 9;
    turretTraits.shotY = -5;
  }

  //turret 7 stats
  if (turretTraits.type == 7) {
    turretTraits.size = 20;
    turretTraits.dmg = 4;
    turretTraits.accuracy = 4;
    turretTraits.reload = 150;
    turretTraits.speed = 20;
    turretTraits.range = 600;
    turretTraits.shotAmount = 50;
    turretTraits.shotX = 9;
    turretTraits.shotY = -5;
  }

  //turret 8 stats (not offensive)
  if (turretTraits.type == 8) {
    turretTraits.size = 20;
    turretTraits.dmg = 0;
    turretTraits.accuracy = 0;
    turretTraits.reload = 0;
    turretTraits.speed = 0;
    turretTraits.range = 0;
    turretTraits.shotAmount = 0;
    turretTraits.shotX = 0;
    turretTraits.shotY = 0;
  }

  //turret 9 stats (not offensive)
  if (turretTraits.type == 9) {
    turretTraits.size = 20;
    turretTraits.dmg = 0;
    turretTraits.accuracy = 0;
    turretTraits.reload = 0;
    turretTraits.speed = 0;
    turretTraits.range = 0;
    turretTraits.shotAmount = 0;
    turretTraits.shotX = 0;
    turretTraits.shotY = 0;
  }



  //these variables are independent from the type
  turretTraits.reloadTimer = 0;
  turretTraits.rot = 180;
  turretTraits.locked = -1;
  Turrets.push(turretTraits);
};
var drawTurret = function() {

  for (var i = 0; i < Turrets.length; i++) {
    //graphics
    push();
    translate(Turrets[i].x, Turrets[i].y);
    rotate(Turrets[i].rot);

    //turret 1 gun graphics
    if (Turrets[i].type == 1) {
      noStroke();
      fill(50);
      rect(10, -5, 17, 2);
      fill(100);
      rect(10, -5, 15, 3);
      fill(0, 255, 255);
      rect(14, -5, 2.5, 1);
    }

    //turret 2 gun graphics
    if (Turrets[i].type == 2) {
      noStroke();
      fill(50);
      rect(10, -5, 17, 2);
      quad(18, -5.5, 18, -4.5, 22, -3, 22, -7);
      fill(100);
      rect(10, -5, 17, 3);
      fill(0, 255, 255);
      rect(14, -5, 2.5, 1);
    }

    //turret 3 gun graphics
    if (Turrets[i].type == 3) {
      noStroke();
      fill(50);
      rect(12, -5, 30, 2);
      fill(100);
      rect(10, -5, 17, 3);
      fill(0, 255, 255);
      rect(14, -5, 2.5, 1);
    }

    //turret 4 gun graphics
    if (Turrets[i].type == 4) {
      noStroke();
      fill(50);
      rect(12, -5, 26, 3);
      quad(25, -5.5, 25, -4.5, 29, -3, 29, -7);
      fill(100);
      rect(10, -5, 15, 5);
      fill(0, 255, 255);
      rect(12, -5, 9, 1);
    }

    //turret 5 gun graphics
    if (Turrets[i].type == 5) {
      noStroke();
      fill(50);
      rect(12, -3.5, 26, 2);
      rect(12, -6.5, 26, 2);
      fill(100);
      rect(10, -5, 15, 7);
      fill(0, 255, 255);
      rect(12, -3.5, 9, 1);
      rect(12, -6.5, 9, 1);
    }

    //turret 6 gun graphics
    if (Turrets[i].type == 6) {
      noStroke();
      fill(50);
      triangle(10, -6, 30, -6, 15, -8);
      triangle(10, -4, 30, -4, 15, -2);
      fill(100);
      rect(10, -5, 17, 3);
      fill(0, 255, 255);
      rect(14, -5, 2.5, 1);
    }

    //turret 7 gun graphics
    if (Turrets[i].type == 7) {
      noStroke();
      fill(0, 255, 255);
      rect(10, -5, 20, 2);
      fill(50);
      rect(10, -5, 2, 4);
      rect(13, -5, 2, 4);
      rect(16, -5, 2, 4);
      rect(19, -5, 2, 4);
    }

    //turrent 8 graphics/functionality
    if (Turrets[i].type == 8) {
      push();
      if (baseHp < baseMaxHp && pause == false) {
        rotate(frameCount % 10);
        baseHp += 0.1;
      }
      noFill();
      strokeWeight(2);
      stroke(100);
      line(4, -12, 15, 0);
      arc(2, -14, 5, 5, 270, 180);
      arc(16.5, 1, 5, 5, 90, 0);
      pop();

    }

    //turrent 9 graphics/functionality
    if (Turrets[i].type == 9) {
      push();
      if (pause == false) {
        scale((frameCount % 50) / 500 + 1);
        money += 0.1;
      }
      rotate(40);
      stroke(32, 107, 0);
      strokeWeight(2);
      fill(51, 179, 0);
      rect(0, -15, 20, 10);
      fill(255, 213, 0);
      textSize(10);
      noStroke();
      text("$", 0, -12);
      pop();
    }



    //body
    noStroke();
    fill(50);
    ellipse(0, 0, 20, 20);
    strokeWeight(1);
    stroke(0, 255, 255);
    line(9, -2.5, -1, -2.5);
    line(-1, -2.5, -6, -7.5);
    line(9, 2.5, -1, 2.5);
    line(-1, 2.5, -6, 7.5);
    pop();

    if (Turrets[i].type < 8) {

      //target acquisition
      if (Turrets[i].locked < 0) {
        Turrets[i].locked = round(random(-0.4, Enemies.length + 0.4));
      }

      //aiming and shooting and reloading
      if (pause == false) {
        if (Enemies[Turrets[i].locked] && Enemies[Turrets[i].locked].hp > 0 && Turrets[i].locked >= 0 && dist(Turrets[i].x, Turrets[i].y, Enemies[Turrets[i].locked].x, Enemies[Turrets[i].locked].y) <= Turrets[i].range) {
          Turrets[i].rot = atan2(Enemies[Turrets[i].locked].y - Turrets[i].y, Enemies[Turrets[i].locked].x - Turrets[i].x);
          if (Turrets[i].reloadTimer <= 0) {
            for (var i3 = 0; i3 < Turrets[i].shotAmount; i3++) {
              makeBullet(Turrets[i].x, Turrets[i].y, Turrets[i].rot, Turrets[i].shotX, Turrets[i].shotY, color(0, 255, 255, 50), Turrets[i].accuracy, Enemies[Turrets[i].locked].x, Enemies[Turrets[i].locked].y, Turrets[i].speed, Turrets[i].dmg);
            }
            Turrets[i].reloadTimer = Turrets[i].reload;
          }
        } else {
          Turrets[i].locked = -1;
        }
        Turrets[i].reloadTimer--;
      }
    }
  }
};

//fire code
var Fire = [];
var flame = function() {
  this.ogX = 0;
  this.ogY = 0;
  this.x = 0;
  this.y = 0;
  this.h = 0;
  this.v = 0;
  this.rise = 0;
  this.size = 0;
  this.distance = 0;
  this.clr1 = 0;
  this.clr2 = 0;
  this.clr3 = 0;
};
var makeFlame = function(x, y, h, v, size, distance) {
  var flameTraits = new flame(flameTraits);
  flameTraits.x = x;
  flameTraits.y = y;
  flameTraits.ogX = x;
  flameTraits.ogY = y;
  flameTraits.h = h;
  flameTraits.v = v;
  flameTraits.rise = 0;
  flameTraits.size = size;
  flameTraits.distance = distance;
  flameTraits.clr1 = 255;
  flameTraits.clr2 = random(0, 255);
  flameTraits.clr3 = 0;
  Fire.push(flameTraits);
};
var drawFlame = function() {
  for (var i = 0; i < Fire.length; i++) {
    //graphics
    noStroke();
    fill(Fire[i].clr1 - (dist(Fire[i].x, Fire[i].y, Fire[i].ogX, Fire[i].ogY) / Fire[i].distance) * 400, Fire[i].clr2 - (dist(Fire[i].x, Fire[i].y, Fire[i].ogX, Fire[i].ogY) / Fire[i].distance) * 400, Fire[i].clr3, random(50 - (dist(Fire[i].x, Fire[i].y, Fire[i].ogX, Fire[i].ogY) / Fire[i].distance) * 30, 100 - (dist(Fire[i].x, Fire[i].y, Fire[i].ogX, Fire[i].ogY) / Fire[i].distance) * 30));
    ellipse(Fire[i].x, Fire[i].y, Fire[i].size);

    //movement
    Fire[i].x += Fire[i].h;
    Fire[i].rise += Fire[i].v;
    Fire[i].y += Fire[i].rise;

    //removes the dead particles
    if (dist(Fire[i].x, Fire[i].y, Fire[i].ogX, Fire[i].ogY) > Fire[i].distance) {
      Fire.splice(i, 1);
    }

  }
};

//player code
var playerX = 620;
var playerY = 350;
var playerSpeed = 3;
var playerSize = 10;
var playerRotate = 0;
var player = function() {
  //rotation
  playerRotate = atan2(trueMouseY - playerY, trueMouseX - playerX);
  if (pause == false) {
    //movement
    //w
    if (keyIsDown(87)) {
      playerY -= playerSpeed;
    }
    //s
    else if (keyIsDown(83)) {
      playerY += playerSpeed;
    }
    //a
    if (keyIsDown(65)) {
      playerX -= playerSpeed
    }
    //d
    else if (keyIsDown(68)) {
      playerX += playerSpeed;
    }
  }
  //make sure that the player doesn't go off the screen
  playerX = constrain(playerX, 550 + playerSize, 700 - playerSize);
  playerY = constrain(playerY, playerSize, 700 - playerSize);

  //player graphics
  push();
  translate(playerX, playerY);
  rotate(playerRotate);
  //gun
  noStroke();
  fill(0);
  rect(15, -6, 20, 3);
  fill(0, 255, 255);
  rect(15, -6, 20, 1);

  //player
  fill(100);
  ellipse(0, 0, 20);
  fill(0, 255, 255, 230);
  arc(0, 0, 20.5, 20.5, 310, 50);
  fill(80);
  ellipse(0, 0, 15);
  pop();

  //shooting
  if (mouseIsPressed && pause == false) {
    makeBullet(playerX, playerY, playerRotate, 25, -6, color(0, 255, 255, 50), 2, trueMouseX, trueMouseY, 25, 0.3);
  }
};

//game graphics
var land = function() {
  //ground
  var xoff = 0.0;
  for (var x = 0; x < 16; x++) {
    var yoff = 0.0;
    for (var y = 0; y < 20; y++) {
      var bright = map(noise(xoff * 3, yoff * 3), 0, 1, 0, 255);
      strokeWeight(50);
      stroke(10, 150 -bright/5, 0);
      point(x * 36, y * 36);
      yoff += 0.01;
    }
    xoff += 0.01;
  }
};
var base = function() {
  //base graphics
  noStroke();
  fill(150);
  rect(630, 350, 200, 700);
  for (var i3 = 0; i3 < 101; i3++) {
    push();
    translate(530, 0);
    rotate(90);
    fill(0);
    textSize(25);
    text("X", i3 * 7, 0);
    pop();
  }
};
var statBar = function() {
  noStroke();
  fill(150);
  quad(0, 0, 150, 0, 100, 50, 0, 50);
  fill(100);
  rect(60, 15, 110, 20, 10);
  fill(255, 0, 0);
  rect(48, 15, 80, 14, 7);
  rectMode(CORNER);
  fill(0, 255, 0);
  rect(8, 8, (baseHp / baseMaxHp) * 80, 14, 7);
  fill(255);
  textSize(15);
  text("HP", 100, 20);
  fill(0);
  text("Money: " + round(money), 50, 40);
  rectMode(CENTER);

};

//shop stuff
var selected = 0;
var shopping = false;
var canPlace = false;
var sellTimer = 120;
var cost = [50, 60, 100, 200, 800, 1200, 1500, 100, 200];
var info = ["Basic Turret Dmg: 0.3 Accuracy: 1 Reload: 5 Range: 400 Bullet Speed: 10", "Shotgun Turret Dmg: 0.3 Accuracy: 2 Reload: 25 Range: 200 Bullet Speed: 10", "Sniper Turret Dmg: 3 Accuracy: 0.1 Reload: 40 Range: 700 Bullet Speed: 15", "Auto Turret Dmg: 1 Accuracy: 1 Reload: 15 Range: 600 Bullet Speed: 10", "APS Turret Dmg: 0.5 Accuracy: 2 Reload: 2 Range: 550 Bullet Speed: 30", "Railgun Turret Dmg: 150 Accuracy: 0.05 Reload: 500 Range: 900 Bullet Speed: 40", "Spread Turret Dmg: 4 Accuracy: 4 Reload: 150 Range: 600 Bullet Speed: 20", "Repair Turret Repairs damage to the base. Does not attack.", "Revenue Turret Generates money. Does not attack."];
var shop = function() {
  noStroke();
  fill(0, 100);
  rect(270, 350, 555, 700);
  fill(255);
  textSize(30);
  text("SHOP", 275, 50);

  //darkened rectangles
  for (var i = 0; i < 3; i++) {
    for (var i2 = 0; i2 < 3; i2++) {
      push();
      translate(130 + i * 130, 170 + i2 * 200);
      noStroke();
      fill(0, 40);
      rect(0, 0, 100, 100, 10);

      //description
      textAlign(LEFT);
      fill(0);
      if (i + (i2 * 3) !== 6) {
        textSize(13);
      } else {
        textSize(12.2);
      }
      text(info[i + (i2 * 3)], 0, 103, 100, 100);
      textAlign(CENTER);


      //displays the cost
      fill(0);
      textSize(20);
      text("Cost: " + cost[i + (i2 * 3)], 0, -30);
      pop();
    }
  }

  //gun graphics

  //gun 1
  noStroke();
  fill(50);
  rect(120, 170, 4, 35);
  fill(100);
  rect(120, 170, 6, 30);
  fill(0, 255, 255);
  rect(120, 160, 2, 5);

  //gun 2
  noStroke();
  fill(50);
  quad(248, 155, 252, 155, 255, 145, 245, 145);
  fill(100);
  rect(250, 170, 6, 35);
  fill(0, 255, 255);
  rect(250, 160, 2, 5);

  //gun 3
  noStroke();
  fill(50);
  rect(380, 170, 4, 75);
  fill(100);
  rect(380, 170, 6, 35);
  fill(0, 255, 255);
  rect(380, 160, 2, 5);

  //gun 4
  noStroke();
  fill(50);
  rect(120, 370, 6, 75);
  quad(119, 333, 121, 333, 125, 325, 115, 325);
  fill(100);
  rect(120, 370, 9, 30);
  fill(0, 255, 255);
  rect(120, 367, 2, 19);

  //gun 5
  noStroke();
  fill(50);
  rect(247, 370, 4, 75);
  rect(253, 370, 4, 75);
  fill(100);
  rect(250, 370, 13, 30);
  fill(0, 255, 255);
  rect(247, 367, 2, 19);
  rect(253, 367, 2, 19);

  //gun 6
  noStroke();
  fill(50);
  triangle(377, 370, 377, 320, 370, 365);
  triangle(383, 370, 383, 320, 390, 365);
  fill(100);
  rect(380, 370, 6, 35);
  fill(0, 255, 255);
  rect(380, 360, 2, 5);

  //gun 7
  noStroke();
  fill(0, 255, 255);
  rect(120, 562, 4, 30);
  fill(50);
  rect(120, 567, 8, 4);
  rect(120, 561, 8, 4);
  rect(120, 555, 8, 4);
  rect(120, 549, 8, 4);

  //turret 8
  strokeWeight(5);
  stroke(90);
  noFill();
  line(253, 562, 233, 582);
  arc(259, 556, 10, 10, 0, 270);
  arc(227, 588, 10, 10, 180, 90);

  //turret 9
  push();
  translate(368, 569);
  strokeWeight(4);
  stroke(32, 107, 0);
  fill(51, 179, 0);
  rotate(-40);
  rect(0, 0, 40, 20);
  fill(255, 213, 0);
  textSize(20);
  noStroke();
  text("$", 0, 7);
  pop();

  //body graphics
  for (var i3 = 0; i3 < 3; i3++) {
    for (var i4 = 0; i4 < 3; i4++) {
      push();
      translate(130 + i3 * 130, 170 + i4 * 200);
      noStroke();
      fill(50);
      ellipse(0, 20, 40, 40);
      stroke(0, 255, 255);
      strokeWeight(2);
      line(-5, 2, -5, 25);
      line(-5, 25, -14, 33);
      line(5, 2, 5, 25);
      line(5, 25, 14, 33);
      pop();

      //button functions
      if (mouseIsPressed && trueMouseX > 80 + i3 * 130 && trueMouseX < 180 + i3 * 130 && trueMouseY > 120 + i4 * 200 && trueMouseY < 220 + i4 * 200 && selected <= 0) {
        selected = i3 + (i4 * 3) + 1;
      }

    }
  }

  if (selected !== 0) {
    canPlace = true;

    if (trueMouseX < 560) {
      canPlace = false;
    }
    if (trueMouseX > 690) {
      canPlace = false;
    }
    if (trueMouseY > 690) {
      canPlace = false;
    }

    for (var i5 = 0; i5 < Turrets.length; i5++) {
      if (dist(Turrets[i5].x, Turrets[i5].y, trueMouseX, trueMouseY) <= Turrets[i5].size) {
        canPlace = false;
      }
    }

    if (canPlace == true) {
      fill(0, 100);
    } else {
      fill(255, 0, 0, 100);
    }
    noStroke();
    ellipse(trueMouseX, trueMouseY, 20);

    if (mouseIsPressed && canPlace == true && money >= cost[selected - 1]) {
      //makes the turret
      makeTurret(selected, trueMouseX, trueMouseY);

      //the money you lose for buying it
      money -= cost[selected - 1];

      selected = 0;
      canPlace = false;
    } else if (mouseIsPressed && money < cost[selected - 1]) {
      fill(255, 0, 0);
      textSize(20);
      text("Not enough money", trueMouseX, trueMouseY - 20);

    }
  }

 
  // return;
  //sell turret
  for (var i6 = 0; i6 < Turrets.length; i6++) {
    if (mouseIsPressed && selected == 0 && dist(trueMouseX, trueMouseY, Turrets[i6].x, Turrets[i6].y) <= Turrets[i6].size / 2) {
      sellTimer--;
      noStroke();
      fill(255, 0, 0, 150);
      arc(Turrets[i6].x, Turrets[i6].y, 30, 30, 270, 270 - (sellTimer * 6));

      if (sellTimer <= 0) {
        //you get half the money back if you sell
        money += cost[Turrets[i6].type - 1] / 2;
        Turrets.splice(i6, 1);
      }
    }
  }

  if(!mouseIsPressed){
    sellTimer = 60;
  }
  // //resets the timer
  // if (!mouseIsPressed || trueMouseX !== pMouseX || trueMouseY !== pMouseY) {
  //   sellTimer = 60;
  // }

  //unselect turret
  noStroke();
  fill(0, 50);
  ellipse(160, 60, 80);
  strokeWeight(7);
  stroke(0);
  line(160, 80, 160, 50);
  line(150, 80, 150, 50);
  line(170, 80, 170, 50);
  line(170, 80, 150, 80);
  line(145, 50, 175, 50);
  noFill();
  strokeWeight(5);
  arc(160, 50, 20, 20, 180, 0);

  if (selected !== 0 && mouseIsPressed && dist(160, 60, trueMouseX, trueMouseY) <= 40) {
    selected = 0;
  }
};

//start scene stuff
var launched = false;
var rocketY = 0;
var boomSize = 0;
var burned = false;
var fireTimer = 0;
var pressY = 0;

//scenes
var start = function() {
  background(0, 174, 255);

  //base
  noStroke();
  fill(133, 133, 133);
  rect(350, 450, 999, 300);

  //wire things
  for (var i = 0; i < 71; i++) {
    push();
    strokeWeight(1);
    translate(-10 + i * 10, 0);
    stroke(0);
    line(0, 300, 20, 275);
    line(0, 275, 20, 300);
    line(0, 275, 20, 265);
    line(20, 275, 0, 265);
    pop();
  }

  //lines
  for (var i2 = 0; i2 < 8; i2++) {
    strokeWeight(3);
    stroke(125);
    line(0, 340 + i2 * 40, 700, 340 + i2 * 40);
    for (var i3 = 0; i3 < 9; i3++) {
      line(40 + i3 * 80 + (i2 & 1) * 40, 300 + i2 * 40, 40 + i3 * 80 + (i2 & 1) * 40, 340 + i2 * 40);
    }
  }

  //ground
  noStroke();
  fill(35, 173, 0);
  rect(350, 650, 999, 100);

  //title
  fill(0);
  noStroke();
  textSize(50);
  text("Missile Defence", 350, 100);

  //button
  fill(130);
  rect(350, 660, 150, 50);
  fill(0);
  ellipse(350, 660, 130, 40);
  rect(350, 655 + pressY / 2, 130, 10 - pressY);
  fill(255, 0, 0);
  ellipse(350, 650 + pressY, 130, 40);
  fill(0);
  textSize(20);
  text("LAUNCH", 350, 655 + pressY);
  stroke(0);
  strokeWeight(2);
  line(291, 665, 267, 672);
  line(267, 672, 257, 675);
  line(257, 675, 273, 685);
  line(273, 685, 262, 710);

  //animation
  if (mouseIsPressed && trueMouseX > 285 && trueMouseX < 415 && trueMouseY > 630 && trueMouseY < 670) {
    pressY = 5;
    launched = true;
  } else {
    pressY = 0;
  }

  //rockets
  if (launched == true && rocketY < 100) {
    rocketY += 1

    push();
    //rocket 1
    translate(0, -rocketY);
    translate(200, 0);
    scale(1 - (rocketY / 300));
    translate(-200, 0);
    noStroke();
    fill(150);
    quad(200, 850, 200, 900, 180, 910, 180, 880);
    quad(200, 850, 200, 900, 220, 910, 220, 880);
    fill(0, 200, 0);
    arc(200, 800, 20, 50, 180, 0);
    fill(200);
    ellipse(200, 800, 20, 20);
    rect(200, 850, 20, 100);
    fill(0);
    ellipse(200, 900, 20, 20);
    //flame
    for (var i4 = 0; i4 < 5; i4++) {
      fill(255, 100, 0, 50);
      ellipse(200, 935, 20 - (i4 * 2) + random(-5, 5), 80 - (i4 * 8) + random(-20, 20));
    }
    fill(150);
    rect(200, 890, 2, 35);
    pop();
    push();
    //rocket 2
    translate(0, rocketY);
    translate(500, 0);
    scale(1 - (rocketY / 200));
    translate(-500, 0);
    noStroke();
    fill(150);
    quad(500, 850, 500, 900, 480, 910, 480, 880);
    quad(500, 850, 500, 900, 520, 910, 520, 880);
    fill(0, 200, 0);
    arc(500, 800, 20, 50, 180, 0);
    fill(200);
    ellipse(500, 800, 20, 20);
    rect(500, 850, 20, 100);
    fill(0);
    ellipse(500, 900, 20, 20);
    //flame
    for (var i5 = 0; i5 < 5; i5++) {
      fill(255, 100, 0, 50);
      ellipse(500, 935, 20 - (i5 * 2) + random(-5, 5), 80 - (i5 * 8) + random(-20, 20));
    }
    fill(150);
    rect(500, 890, 2, 35);
    pop();
  }

  if (rocketY >= 100) {
    noStroke();
    fill(26);
    //hole 1
    beginShape();
    vertex(187, 352);
    vertex(184, 371);
    vertex(135, 377);
    vertex(146, 396);
    vertex(140, 435);
    vertex(175, 455);
    vertex(219, 437);
    vertex(249, 451);
    vertex(265, 413);
    vertex(244, 393);
    vertex(253, 361);
    endShape(CLOSE);

    //hole 2
    beginShape();
    vertex(435, 462);
    vertex(460, 492);
    vertex(441, 518);
    vertex(481, 526);
    vertex(510, 543);
    vertex(539, 526);
    vertex(534, 498);
    vertex(556, 478);
    vertex(510, 437);
    vertex(470, 447);
    endShape(CLOSE);

    //button stuff
    fill(255);
    textSize(20);
    text("PLAY", 201, 408);
    text("HELP", 497, 490);

    if (mouseIsPressed && dist(trueMouseX, trueMouseY, 201, 408) < 50) {
      for (var i8 = 0; i8 < 5; i8++) {
        makeTurret(9, 685, 30 + i8 * 155);
      }
      scene = "GAME";
    }
    if (mouseIsPressed && dist(trueMouseX, trueMouseY, 497, 490) < 50) {
      scene = "HELP";
    }

    if (burned == false) {
      burned = true;
      fireTimer = 20;
    }
    if (fireTimer > 0) {
      fireTimer -= 0.1;
    }
  }

  //makes the fire
  for (var i7 = 0; i7 < fireTimer; i7++) {
    makeFlame(201 + random(-50, 50), 438 + random(-20, 20), random(-2, 2), -random(0.05, 0.2), 10 + random(-5, 5), 220 + random(-100, 100));
    makeFlame(497 + random(-50, 50), 520 + random(-20, 20), random(-2, 2), -random(0.05, 0.2), 10 + random(-5, 5), 220 + random(-100, 100));
  }
  drawFlame();

  //explosion
  if (rocketY >= 100 && boomSize < 1000) {
    for (var i6 = 0; i6 < 30; i6++) {
      noStroke();
      fill(255, 100, 0, 50 - (boomSize / 10));
      ellipse(201, 408, -200 + boomSize + i6 * 20);
      ellipse(497, 490, -200 + boomSize + i6 * 20);
    }
    boomSize += 15;
  }
};
var game = function() {
  background(120, 150, 0);

  //graphics and functions
  land();
  base();
  drawEnemy();
  drawBullet();
  player();
  drawTurret();
  drawFlame();

  //fire (when the base is damaged)
  if (baseHp < 850) {
    makeFlame(541 + random(-5, 5), 438 + random(-20, 20), random(-1, 1), -random(0.05, 0.2), 10 + random(-5, 5), 120 + random(-50, 50));
  }
  if (baseHp < 700) {
    makeFlame(631 + random(-5, 5), 138 + random(-20, 20), random(-1, 1), -random(0.05, 0.2), 10 + random(-5, 5), 120 + random(-50, 50));
  }
  if (baseHp < 550) {
    makeFlame(581 + random(-5, 5), 638 + random(-20, 20), random(-1, 1), -random(0.05, 0.2), 10 + random(-5, 5), 120 + random(-50, 50));
  }
  if (baseHp < 400) {
    makeFlame(661 + random(-5, 5), 338 + random(-20, 20), random(-1, 1), -random(0.05, 0.2), 10 + random(-5, 5), 120 + random(-50, 50));
  }
  if (baseHp < 250) {
    makeFlame(571 + random(-5, 5), 408 + random(-20, 20), random(-1, 1), -random(0.05, 0.2), 10 + random(-5, 5), 120 + random(-50, 50));
  }


  //shopping stuff
  if (keyIsDown(69) && keyDown == false) {
    shopping = !shopping;
  }
  if (shopping == true) {
    pause = true;
    shop();
  } else {
    pause = false;
    selected = 0;
  }

  //stat bar
  statBar();

  //score
  if (pause == false) {
    score++;
  }

  //rocket spawn
  if (pause == false && frameCount % round(timer) == 0) {
    makeEnemy(round(random(spawn1, spawn2)));
  }
  if (pause == false && frameCount % 120 == 0) {
    if (spawn2 < 8.4) {
      spawn2 += 0.1;
    }
    if (spawn1 < 4.5 && spawn2 > 4) {
      spawn1 += 0.1;
    }
    if (timer > 5) {
      timer -= 1;
    }
  }
  if (baseHp <= 0) {
    baseHp = baseMaxHp;
    Bullets.splice(0, Bullets.length);
    Enemies.splice(0, Enemies.length);
    Turrets.splice(0, Turrets.length);
    Fire.splice(0, Fire.length);
    money = 100;
    timer = 200;
    spawn1 = 0.5;
    spawn2 = 1;
    scene = "END";
  }

  textSize(20);
  fill(0);
  noStroke();
};
var end = function() {
  background(0, 174, 255);
  noStroke();
  fill(255, 100, 0, 20);
  for (var i = 0; i < 28; i++) {
    ellipse(350, 350, i * 50);
  }

  textSize(40);
  fill(0);
  text("Your base blew up", 350, 100);
  textSize(20);
  text("You lost with a score of: " + score, 350, 200);

  //menu button
  fill(150);
  ellipse(350, 500, 200);
  fill(100);
  arc(350, 500, 200, 200, 310, 130);
  fill(0);
  textSize(50);
  text("MENU", 350, 520);
  if (mouseIsPressed && dist(trueMouseX, trueMouseY, 350, 500) < 100) {
    scene = "START";
  }

};
var help = function() {
  background(0, 174, 255);
  noStroke();
  fill(0);
  textSize(50);
  text("HELP", 350, 100);
  textAlign(LEFT);
  textSize(20);
  text("Aim with the mouse and hold the left mouse button to shoot. Move with WASD. Press E to open and close the shop. In the shop, you can buy turrets. Click the turret that you want to buy and then click again on place you want to put it. If you selected the wrong turret, click on the trash can to unselect. To sell a turret, hold the left mouse button over the turret you would like to sell. Selling a turret gives you half the amount of money that you bought it for. Don't let the missiles hit your base. Good luck.", 350, 670, 660, 999);
  textAlign(CENTER);

  //menu button
  fill(150);
  ellipse(350, 500, 200);
  fill(100);
  arc(350, 500, 200, 200, 310, 130);
  fill(0);
  textSize(50);
  text("MENU", 350, 520);
  if (mouseIsPressed && dist(trueMouseX, trueMouseY, 350, 500) < 100) {
    scene = "START";
    score = 0;
  }

};

function setup() {
  // createCanvas(700, 700);

  createCanvas(windowWidth, windowHeight);
  scaleMod = height / 700;
  displayCut = (width - (height)) / 2;

  angleMode(DEGREES);
  rectMode(CENTER);
  textAlign(CENTER);
}

function draw() {

  //sets the true MouseX
  trueMouseX = (mouseX - displayCut) / scaleMod;
  trueMouseY = mouseY / scaleMod;
  trueMouseX = constrain(trueMouseX, 0, 700);
  trueMouseY = constrain(trueMouseY, 0, 700);

  //translates the game so it fits fullscreen and displays it
  push();
  translate(displayCut, 0);
  scale(scaleMod);

  if (scene == "START") {
    start();
  }
  if (scene == "GAME") {
    game();
  }
  if (scene == "END") {
    end();
  }
  if (scene == "HELP") {
    help();
  }

  pop();

  //removes the bullets that are dead
  for (var i = 0; i < Bullets.length; i++) {
    if (Bullets[i].explode == true) {
      Bullets.splice(i, 1);
    }
  }

  //removes the enemys that are dead
  for (var i2 = 0; i2 < Enemies.length; i2++) {
    if (Enemies[i2].explode == true) {
      Enemies.splice(i2, 1);
    }
  }

  //make sure that the base hp will never surpass the base max hp
  if (baseHp > baseMaxHp) {
    baseHp = baseMaxHp;
  }

  //controls keydown
  if (keyIsPressed) {
    keyDown = true;
  } else {
    keyDown = false;
  }

  push();
  rectMode(CORNER);
  noStroke();
  fill(28);
  rect(0, 0, displayCut, height);
  rect(width - displayCut, 0, displayCut, height);
  pop();


}