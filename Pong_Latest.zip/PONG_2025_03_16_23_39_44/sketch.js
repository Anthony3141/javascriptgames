function setup() {
  // createCanvas(700, 500);
  createCanvas(windowWidth, windowHeight);

  scaleMod = height / 500;
  displayCut = (width - (height * 7 / 5)) / 2;


  angleMode(DEGREES);
}

//game variables
var scene = "MENU";
var player1Score = 0;
var player2Score = 0;
var mouseDown = false;

//display variables
var scaleMod;
var displayCut;
var trueMouseX = 0;
var trueMouseY = 0;


//paddle graphics
var paddleLeftY = 250;
var paddleExplodeL = 900;
var paddleLeft = function() {
  push();
  translate(0, paddleLeftY);
  noStroke();
  fill(30);
  rectMode(CENTER);
  rect(50, 0, 20, 100);
  fill(255, 0, 0);
  rect(50, -35, 2, 30);
  rect(50, 35, 2, 30);
  rect(45, 0, 2, 30);
  noFill();
  stroke(255, 0, 0);
  strokeWeight(2);
  line(50, -20, 45, -15);
  line(50, 20, 45, 15);
  line(45, -3, 60, -7);
  line(45, 3, 60, 7);
  strokeWeight(2);
  for (var i = 0; i < 4; i++) {
    line(47 + (i * 4), -3 - (i / 1.4), 47 + (i * 4), 3 + (i / 1.4));
  }
  noStroke();
  fill(255, 0, 0, 255 - paddleExplodeL * 4);
  arc(60, 0, paddleExplodeL * 2, paddleExplodeL * 2, 270, 90);
  paddleExplodeL += 2;
  pop();
};

var paddleRightY = 250;
var paddleExplodeR = 500;
var paddleRight = function() {
  push();
  translate(0, paddleRightY);
  noStroke();
  fill(255);
  rectMode(CENTER);
  rect(650, 0, 20, 100);
  fill(0, 255, 255);
  rect(650, -35, 2, 30);
  rect(650, 35, 2, 30);
  rect(655, 0, 2, 30);
  fill(0);
  ellipse(640, 0, 15, 30);
  fill(255);
  arc(640, 0, 7, 14, 270, 90);

  strokeWeight(2);
  stroke(0, 255, 255);
  line(650, -20, 655, -15);
  line(650, 20, 655, 15);
  stroke(255);
  line(642, -2, 650, -2);
  line(642, 2, 650, 2);

  noStroke();
  fill(0, 255, 255, 255 - paddleExplodeR * 3);
  arc(640, 0, paddleExplodeR, paddleExplodeR, 90, 270);
  paddleExplodeR += 2;
  pop();
};


//ball stuff
var ballX = 350;
var ballY = 250;
var ballH = 5;
var ballV = 5;
var ballSize = 30;
var ballAnimation = 0;
var animation = function() {
  stroke(0, 255, 255);
  strokeWeight(1);
  if (ballAnimation == 0) {
    //top thing
    line(-7, -15, -9, -19);
    line(-9, -19, -3, -21);
    line(-3, -21, -3, -25);
    line(-3, -25, 6, -26);
    line(6, -26, 6, -21);
    line(6, -21, 10, -17);
    line(10, -17, 7, -11);

    //bottom left thing 
    line(-11, 3, -20, -1);
    line(-20, -1, -22, 3);
    line(-22, 3, -30, 5);
    line(-30, 5, -30, 9);
    line(-30, 9, -20, 11);
    line(-20, 11, -15, 9);
    line(-15, 9, -14, 16);
    line(-14, 16, -7, 9);

    //bottom right thing
    line(7, 9, 8, 16);
    line(8, 16, 13, 15);
    line(13, 15, 15, 18);
    line(15, 18, 23, 14);
    line(23, 14, 19, 11);
    line(19, 11, 13, 13);
    line(13, 13, 11, 7);
  }
  if (ballAnimation == 1) {
    //top thing
    line(-5, -13, -10, -22);
    line(-10, -22, -6, -25);
    line(-6, -25, -7, -34);
    line(-7, -34, -1, -37);
    line(-1, -37, 3, -33);
    line(3, -33, 0, -27);
    line(0, -27, 9, -19);
    line(9, -19, 6, -10);

    //bottom left thing
    line(-12, 3, -17, 0);
    line(-17, 0, -19, 4);
    line(-19, 4, -27, 5);
    line(-27, 5, -29, 12);
    line(-29, 12, -19, 11);
    line(-19, 11, -15, 14);
    line(-15, 14, -9, 9);

    //bottom right thing
    line(7, 9, 7, 15);
    line(7, 15, 13, 14);
    line(13, 14, 11, 19);
    line(11, 19, 25, 14);
    line(25, 14, 20, 12);
    line(20, 12, 21, 5);
    line(21, 5, 15, 9);
    line(15, 9, 11, 5);
  }
  if (ballAnimation == 2) {
    //top thing
    line(-4, -13, -11, -19);
    line(-11, -19, -4, -29);
    line(-4, -29, 4, -28);
    line(4, -28, 2, -23);
    line(2, -23, 11, -22);
    line(11, -22, 6, -14);

    //bottom left thing
    line(-13, 2, -16, 1);
    line(-16, 1, -18, 4);
    line(-18, 4, -24, 4);
    line(-24, 4, -22, 10);
    line(-22, 10, -19, 9);
    line(-19, 9, -16, 13);
    line(-16, 13, -11, 9);

    //bottom right thing
    line(6, 9, 7, 14);
    line(7, 14, 14, 14);
    line(14, 14, 19, 24);
    line(19, 24, 21, 14);
    line(21, 14, 17, 11);
    line(17, 11, 19, 5);
    line(19, 5, 9, 3);

  }
  if (ballAnimation == 3) {
    //top thing
    line(-4, -13, -10, -20);
    line(-10, -20, -6, -20);
    line(-6, -20, -1, -23);
    line(-1, -23, 8, -20);
    line(8, -20, 6, -14);

    //bottom left thing
    line(-13, 1, -18, 0);
    line(-18, 0, -19, 5);
    line(-19, 5, -24, 12);
    line(-24, 12, -22, 17);
    line(-22, 17, -15, 11);
    line(-15, 11, -11, 13);
    line(-11, 13, -10, 7);

    //bottom right thing
    line(6, 10, 8, 14);
    line(8, 14, 13, 15);
    line(13, 15, 17, 18);
    line(17, 18, 20, 12);
    line(20, 12, 16, 10);
    line(16, 10, 13, 3);
  }
  if (ballAnimation == 4) {
    //top thing
    line(-7, -13, -4, -23);
    line(-4, -23, 0, -20);
    line(0, -20, 6, -23);
    line(6, -23, 7, -12);

    //bottom left thing
    line(-13, -1, -20, -1);
    line(-20, -1, -19, 6);
    line(-19, 6, -27, 5);
    line(-27, 5, -22, 12);
    line(-22, 12, -17, 8);
    line(-17, 8, -10, 7);

    //bottom right thing
    line(7, 10, 6, 14);
    line(6, 14, 10, 14);
    line(10, 14, 19, 19);
    line(19, 19, 22, 15);
    line(22, 15, 23, 11);
    line(23, 11, 17, 11);
    line(17, 11, 14, 4);
  }
};

var pastLeftSide = 0;
var pastRightSide = 0;
var movingLeft = false;
var scoreLeft = false;
var scoreRight = false;
var timer = 100;

var scoreTimer = 999;
var scoreX = 0;
var scoreY = 0;
var scoreAnimation = function(x, y) {
  noStroke();
  fill(0, 255, 255, 255 - scoreTimer * 2);
  ellipse(x, y, scoreTimer * 4);
  scoreTimer++;
}

var ball = function() {
  //graphics
  push();
  translate(ballX, ballY);
  noStroke();
  for (var i = 0; i < 100; i++) {
    fill(0, 255, 255, 1);
    ellipse(0, 0, ballSize + (i / 2));
  }
  fill(230, 255, 255);
  ellipse(0, 0, ballSize);
  push();
  rotate(frameCount * ballAnimation);
  animation();
  pop();
  pop();
  if (frameCount % 3 == 0) {
    ballAnimation++;
  }
  if (ballAnimation > 4) {
    ballAnimation = 0;
  }

  //collisions of the ball
  if (timer <= 0) {
    if (movingLeft == false) {
      ballX += ballH;
    } else {
      ballX -= ballH;
    }
    ballY += ballV;
  }
  if (ballY <= ballSize / 2 || ballY >= 500 - (ballSize / 2)) {
    ballV = -1 * ballV;
  }

  //collisions with the paddles

  //right
  if (ballX >= 640 - (ballSize / 2) && dist(paddleRightY, 0, ballY, 0) < 50 && pastRightSide == 0) {
    movingLeft = true;
    //if it hits the center of the paddle
    if (dist(paddleRightY, 0, ballY, 0) < 7) {
      ballH += 2;
      ballV = random(-10, 10);
      paddleExplodeR = 0;
    }
  }
  if (ballX > 640 - (ballSize / 2) && dist(paddleRightY, 0, ballY, 0) >= 50) {
    if (paddleRightY < ballY) {
      pastRightSide = 2;
    } else {
      pastRightSide = 1;
    }
  }
  if (dist(paddleRightY, 0, ballY, 0) < 50 + (ballSize / 2) && pastRightSide !== 0 && ballX < 660 + (ballSize / 2)) {
    if (pastRightSide == 1) {
      ballY = paddleRightY - 50 - (ballSize / 2);
      ballV = abs(ballV) * -1;
    }
    if (pastRightSide == 2) {
      ballY = paddleRightY + 50 + (ballSize / 2);
      ballV = -abs(ballV);
    }
  }

  //left
  if (ballX <= 60 + (ballSize / 2) && dist(paddleLeftY, 0, ballY, 0) < 50 && pastLeftSide == 0) {
    movingLeft = false;
    if (dist(paddleLeftY, 0, ballY, 0) < 7) {
      ballH += 2;
      ballV = random(-10, 10);
      paddleExplodeL = 0;
    }
  }
  if (ballX < 60 + (ballSize / 2) && dist(paddleLeftY, 0, ballY, 0) >= 50) {
    if (paddleLeftY < ballY) {
      pastLeftSide = 2;
    } else {
      pastLeftSide = 1;
    }
  }
  if (dist(paddleLeftY, 0, ballY, 0) < 50 + (ballSize / 2) && pastLeftSide !== 0 && ballX > 40 - (ballSize / 2)) {
    if (pastLeftSide == 1) {
      ballY = paddleLeftY - 50 - (ballSize / 2);
      ballV = abs(ballV) * -1;
    }
    if (pastLeftSide == 2) {
      ballY = paddleLeftY + 50 + (ballSize / 2);
      ballV = abs(ballV);
    }
  }

  if (ballX >= 700) {
    scoreRight = true;
  }
  if (ballX <= 0) {
    scoreLeft = true;
  }
  if (scoreRight == true) {
    player1Score++;
    scoreTimer = 0;
    scoreY = ballY;
    scoreX = 700;
    timer = 70;
    ballX = 350;
    ballY = 250;
    ballH = random(3, 5);
    ballV = random(-5, 5);
    movingLeft = false;
    pastRightSide = 0;
    pastLeftSide = 0;
    scoreRight = false;
  }
  if (scoreLeft == true) {
    player2Score++;
    scoreTimer = 0;
    scoreY = ballY;
    scoreX = 0;
    timer = 70;
    ballX = 350;
    ballY = 250;
    ballH = random(3, 5);
    ballV = random(-5, 5);
    movingLeft = true;
    pastRightSide = 0;
    pastLeftSide = 0;
    scoreLeft = false;
  }

  //counts down the timer
  timer--;

  scoreAnimation(scoreX, scoreY);

  //makes sure that the ball doesn't go off the map
  ballY = constrain(ballY, ballSize / 2, 500 - (ballSize / 2));
  ballX = constrain(ballX, 0, 700);
};

var difficulty = "NORMAL";
var difficulty2 = "PLAYER";

//code for easy bot
var easySpeed = 2;
var botEasy = function() {
  if (paddleLeftY > ballY) {
    paddleLeftY -= easySpeed;
  } else if (paddleLeftY < ballY) {
    paddleLeftY += easySpeed;
  }
};
var botEasy2 = function() {
  if (paddleRightY > ballY) {
    paddleRightY -= easySpeed;
  } else if (paddleRightY < ballY) {
    paddleRightY += easySpeed;
  }
};

//code for normal bot
var normalSpeed = 5;
var botNormal = function() {
  if (dist(paddleLeftY, 0, ballY, 0) < normalSpeed) {
    paddleLeftY = ballY;
  }
  if (paddleLeftY > ballY) {
    paddleLeftY -= normalSpeed;
  } else if (paddleLeftY < ballY) {
    paddleLeftY += normalSpeed;
  }

};
var botNormal2 = function() {
  if (dist(paddleRightY, 0, ballY, 0) < normalSpeed) {
    paddleRightY = ballY;
  }
  if (paddleRightY > ballY) {
    paddleRightY -= normalSpeed;
  } else if (paddleRightY < ballY) {
    paddleRightY += normalSpeed;
  }

};


//code for hard bot
var simX = 0;
var simY = 0;
var simV = 0;
var calculationTime = 0;
var hardSpeed = 7;
var botHard = function() {

  //if the ball is not coming towards the bot
  if (movingLeft == false) {
    if (dist(paddleLeftY, 0, ballY, 0) < hardSpeed) {
      paddleLeftY = ballY;
    }

    if (paddleLeftY > ballY) {
      paddleLeftY -= hardSpeed;
    } else if (paddleLeftY < ballY) {
      paddleLeftY += hardSpeed;
    }
  }
  //if the ball is coming towards the bot
  else {
    simV = ballV;
    simX = ballX;
    simY = ballY;
    while (simX > 60 + (ballSize / 2) && calculationTime < 700) {
      calculationTime++;
      simX -= ballH;
      simY += simV;

      if (simY <= ballSize / 2 || simY >= 500 - (ballSize / 2)) {
        simV = -1 * simV;
      }
      simX = constrain(simX, ballSize / 2, 700 - (ballSize / 2));
      simY = constrain(simY, ballSize / 2, 500 - (ballSize / 2));
    }
    calculationTime = 0;

    //moves towards the predicted area
    if (paddleLeftY < simY) {
      paddleLeftY += hardSpeed;
    }
    if (paddleLeftY > simY) {
      paddleLeftY -= hardSpeed;
    }

  }
};
var botHard2 = function() {

  //if the ball is not coming towards the bot
  if (movingLeft == true) {
    if (dist(paddleRightY, 0, ballY, 0) < hardSpeed) {
      paddleRightY = ballY;
    }

    if (paddleRightY > ballY) {
      paddleRightY -= hardSpeed;
    } else if (paddleRightY < ballY) {
      paddleRightY += hardSpeed;
    }
  }
  //if the ball is coming towards the bot
  else {
    simV = ballV;
    simX = ballX;
    simY = ballY;
    while (simX < 640 - (ballSize / 2) && calculationTime < 700) {
      calculationTime++;
      simX += ballH;
      simY += simV;

      if (simY <= ballSize / 2 || simY >= 500 - (ballSize / 2)) {
        simV = -1 * simV;
      }
      simX = constrain(simX, ballSize / 2, 700 - (ballSize / 2));
      simY = constrain(simY, ballSize / 2, 500 - (ballSize / 2));
    }
    calculationTime = 0;

    //moves towards the predicted area
    if (paddleRightY < simY) {
      paddleRightY += hardSpeed;
    }
    if (paddleRightY > simY) {
      paddleRightY -= hardSpeed;
    }

  }
};

//impossible bot
var simX3=0;
var simY3=0;
var simV3=0;
var botImpossible = function() {
  //if the ball is not coming towards the bot
  if (movingLeft == true) {
    paddleRightY=250;
  }
  //if the ball is coming towards the bot
  else {
    simV3 = ballV;
    simX3 = ballX;
    simY3 = ballY;
    while (simX3 < 640 - (ballSize / 2) && calculationTime < 700) {
      calculationTime++;
      simX3 += ballH;
      simY3 += simV3;

      if (simY3 <= ballSize / 2 || simY3 >= 500 - (ballSize / 2)) {
        simV3 = -1 * simV3;
      }
      simX3 = constrain(simX3, ballSize / 2, 700 - (ballSize / 2));
      simY3 = constrain(simY3, ballSize / 2, 500 - (ballSize / 2));
    }
    calculationTime = 0;

    //moves towards the predicted area
    paddleRightY=simY3;
  }
};


var buttonGlow = 0;
var p2Select = false;
var p2move = 0;
var menu = function() {
  background(0);
  noStroke();
  textAlign(CENTER);
  rectMode(CORNER);
  textSize(50);
  fill(255);
  text("PONG", 350, 100);
  textSize(20);
  text("Move the mouse to control the paddle on the right, if you hit the ball with the center of the paddle, it will return the ball faster", 150, 150, 400, 400);

  //difficulty select
  rectMode(CENTER);
  for (var k = 0; k < 20; k++) {
    if (difficulty == "EASY") {
      fill(255 - (k * 10), 0, 0);
      rect(279, 450, 60 - (k * 2), 30 - k, 10);
    }
    if (difficulty == "NORMAL") {
      fill(255 - (k * 10), 0, 0);
      rect(350, 450, 82 - (k * 2), 30 - k);
    }
    if (difficulty == "HARD") {
      fill(255 - (k * 10), 0, 0);
      rect(421, 450, 60 - (k * 2), 30 - k, 10);
    }
  }

  noFill();
  stroke(255);
  strokeWeight(2);
  rect(350, 450, 200, 30, 10);
  line(308, 435, 308, 465);
  line(392, 435, 392, 465);
  noStroke();
  fill(255);
  textSize(18);
  text("EASY", 280, 456);
  text("NORMAL", 350, 456);
  text("HARD", 420, 456);
  rectMode(CORNER);

  if (mouseIsPressed && trueMouseY > 435 && trueMouseY < 465 && mouseDown == false) {
    if (trueMouseX > 250 && trueMouseX < 308) {
      difficulty = "EASY";
    }
    if (trueMouseX > 308 && trueMouseX < 392) {
      difficulty = "NORMAL";
    }
    if (trueMouseX > 392 && trueMouseX < 450) {
      difficulty = "HARD"
    }
  }

  if (mouseIsPressed && mouseDown == false && trueMouseX > 280 && trueMouseX < 420 && trueMouseY > 63 && trueMouseY < 100) {
    p2Select = !p2Select;
  }
  if (p2move > 0) {
    rectMode(CENTER);
    if (difficulty2 == "EASY") {
      push();
      translate(-p2move, 0);
      for (var i2 = 0; i2 < 20; i2++) {
        noStroke();
        fill(255 - (i2 * 10), 0, 0);
        rect(304, 83, 59 - (i2 * 2), 30 - i2, 10);
      }
      pop();
    }
    if (difficulty2 == "PLAYER") {
      push();
      translate(-p2move, 0);
      for (var i3 = 0; i3 < 20; i3++) {
        noStroke();
        fill(255 - (i3 * 10), 0, 0);
        rect(378, 83, 93 - (i3 * 2), 30 - i3, 10);
      }
      pop();
    }
    if (difficulty2 == "NORMAL") {
      push();
      translate(p2move, 0);
      for (var i4 = 0; i4 < 20; i4++) {
        noStroke();
        fill(255 - (i4 * 10), 0, 0);
        rect(322, 83, 93 - (i4 * 2), 30 - i4, 10);
      }
      pop();
    }

    if (difficulty2 == "HARD") {
      push();
      translate(p2move, 0);
      for (var i5 = 0; i5 < 20; i5++) {
        noStroke();
        fill(255 - (i5 * 10), 0, 0);
        rect(396, 83, 59 - (i5 * 2), 30 - i5, 10);
      }
      pop();
    }

    noFill();
    stroke(255);
    strokeWeight(2);
    textAlign(CENTER);
    textSize(18);
    push();
    translate(-p2move, 0);
    rect(350, 83, 150, 30, 10);
    line(332, 68, 332, 98);
    noStroke();
    fill(255);
    text("EASY", 305, 89);
    text("PERSON", 378, 89);
    pop();

    push();
    translate(p2move, 0);
    rect(350, 83, 150, 30, 10);
    line(368, 68, 368, 98);
    noStroke();
    fill(255);
    text("NORMAL", 321, 89);
    text("HARD", 396, 89);
    pop();

    push();
    translate(0, -p2move / 3);
    noStroke();
    fill(255);
    text("Select player 2", 350, 90);

    pop();

    //buttons
    if (mouseIsPressed && mouseDown == false && trueMouseY > 68 && trueMouseY < 98) {
      if (trueMouseX > 115 && trueMouseX < 172) {
        difficulty2 = "EASY";
      }
      if (trueMouseX > 172 && trueMouseX < 265) {
        difficulty2 = "PLAYER";
      }
      if (trueMouseX > 435 && trueMouseX < 528) {
        difficulty2 = "NORMAL";
      }
      if (trueMouseX > 528 && trueMouseX < 584) {
        difficulty2 = "HARD";
      }

    }

  }
  if (p2move < 160 && p2Select == true) {
    p2move += 5;
  }
  if (p2move > 0 && p2Select == false) {
    p2move -= 5;
  }








  //play button
  noStroke();
  for (var i = 0; i < buttonGlow; i++) {
    fill(255, 0, 0, 30);
    arc(350, 340, 120 + i * 2, 120 + i * 2, 320, 140);
    fill(0, 255, 255, 30);
    arc(350, 340, 120 + i * 2, 120 + i * 2, 140, 320);
  }
  fill(255);
  ellipse(350, 340, 120);
  fill(0);
  arc(350, 340, 122 - i / 5, 122 - i / 5, 320, 140);
  textSize(30);
  fill(0);
  textAlign(CENTER);
  text("PL", 330, 343);
  fill(255);
  text("AY", 370, 357);
  if (dist(trueMouseX, trueMouseY, 350, 340) < 60) {
    buttonGlow++;
  } else if (buttonGlow > 0) {
    buttonGlow--;
  }
  if (buttonGlow > 10) {
    buttonGlow = 10;
  }
  if (mouseIsPressed && mouseDown == false && dist(trueMouseX, trueMouseY, 350, 340) < 60) {
    scene = "GAME";
  }



};
var game = function() {
  background(0);
  textAlign(CENTER);
  textSize(130);
  noStroke();
  fill(255, 100);
  text(player1Score, 200, 295);
  text(player2Score, 500, 295);
  for (var i = 0; i < 32; i++) {
    fill(255, 100);
    rect(349, i * 16, 2, 10);
  }

  paddleLeft();
  paddleRight();
  ball();

  if (difficulty2 == "PLAYER") {
    paddleRightY = trueMouseY;
  }
  if (difficulty2 == "EASY") {
    botEasy2();
  }
  if (difficulty2 == "NORMAL") {
    botNormal2();
  }
  if (difficulty2 == "HARD") {
    botHard2();
  }
  if (difficulty2 == "IMPOSSIBLE") {
    botImpossible();
  }

  if (difficulty == "EASY") {
    botEasy();
  }
  if (difficulty == "NORMAL") {
    botNormal();
  }
  if (difficulty == "HARD") {
    botHard();
  }
  if (ballH > 60) {
    ballH = 60;
  }

  paddleRightY = constrain(paddleRightY, 0, 500);

  if (player1Score >= 10) {
    player1Score = 0;
    player2Score = 0;
    ballX = 350;
    ballY = 250;
    ballH = 5;
    ballV = 5;
    movingLeft = false;
    timer = 100;
    paddleLeftY = 250;
    paddleExplodeL = 900;
    paddleExplodeR = 900;
    pastLeftSide = 0;
    pastRightSide = 0;
    scoreTimer = 999;
    scene = "LOSE";
  }
  if (player2Score >= 10) {
    player1Score = 0;
    player2Score = 0;
    ballX = 350;
    ballY = 250;
    ballH = 5;
    ballV = 5;
    movingLeft = false;
    timer = 100;
    paddleLeftY = 250;
    paddleExplodeL = 900;
    paddleExplodeR = 900;
    pastLeftSide = 0;
    pastRightSide = 0;
    scoreTimer = 999;
    scene = "WIN";
  }

};
var win = function() {
  background(0);
  textSize(50);
  textAlign(CENTER);
  fill(255);
  noStroke();
  text("YOU WON", 350, 100);
  textSize(20);
  text("Congratulations, you beat the " + difficulty + " bot, well done", 350, 200);
  fill(255);
  ellipse(350, 350, 120);
  textSize(30);
  fill(0);
  noStroke();
  text("MENU", 350, 360);
  if (dist(trueMouseX, trueMouseY, 350, 350) < 60) {
    fill(0, 100);
    ellipse(350, 350, 120);
    if (mouseIsPressed && mouseDown == false) {
      scene = "MENU";
    }
  }
};
var lose = function() {
  background(0);
  textSize(50);
  textAlign(CENTER);
  fill(255);
  noStroke();
  text("YOU LOST", 350, 100);
  textSize(20);
  text("You miserably lost against the " + difficulty + " bot, you're bad", 350, 200);
  fill(255);
  ellipse(350, 350, 120);
  textSize(30);
  fill(0);
  noStroke();
  text("MENU", 350, 360);
  if (dist(trueMouseX, trueMouseY, 350, 350) < 60) {
    fill(0, 100);
    ellipse(350, 350, 120);
    if (mouseIsPressed && mouseDown == false) {
      scene = "MENU";
    }
  }
};

function draw() {
  
  if (keyIsDown(72) && keyIsDown(65) && keyIsDown(88)) {
    difficulty2 = "IMPOSSIBLE";
  }

  trueMouseX = (mouseX - displayCut) / scaleMod;
  trueMouseY = mouseY / scaleMod;

  push();
  translate(displayCut, 0);
  scale(scaleMod);
  
  if (scene == "MENU") {
    menu();
  }
  if (scene == "GAME") {
    game();
  }
  if (scene == "LOSE") {
    lose();
  }
  if (scene == "WIN") {
    win();
  }
  if (mouseIsPressed) {
    mouseDown = true;
  } else {
    mouseDown = false;
  }

  pop();

// blocks out part of the screen
push();
rectMode(CORNER);
noStroke();
fill(28);
rect(0, 0, displayCut, height);
rect(width - displayCut, 0, displayCut, height);
pop();

}