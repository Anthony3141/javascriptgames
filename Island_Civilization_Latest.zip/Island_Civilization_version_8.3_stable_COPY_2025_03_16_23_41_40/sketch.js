///////////////////////////////////////////////GAME VARIABLES////////////////////////////////////////////////
var display = "MENU";
var population = 20;
var defence = 0;
var food = 0;
var energy = 0;
var material = 0;
var threat = 2;
var threatAmount = 0;
var paused = false;
var gettingAttacked = false;
var lose = false;
var won = false;
var runConfirm = false;
var defendConfirm = false;
var difficulty = "NONE";
//affects the difficulty
var difficultyMultiplier = 1;
//tutorial variables
var tutorial = true;
//what part of the tutorial you are on
var tutorialStep = 1;
//the position/size for the rectangle that highlights stuff on the tutorial
var tboxX = 0;
var tboxY = 0;
var tboxSize = 0;
//the text at the top that tells you what to do when your in the tutorial
var dialogue = ""
var dialogueSize = 30;

//the variable that calculates whether you will be attacked or not
var attackedChance = 0;
var mouseOff = true;
//the amount of people that need to die if you don't have enough food
var starving = 0;
//the amount of people that need to die if you choose to defend against an attack
var killed = 0;

//the amount of people you move each time
var moveAmount = 1;

//boosts given by leveling up your buildings
var foodBoost = 1;
var powerBoost = 1;
var materialBoost = 1;
var defenceBoost = 1;


//the timer for cycles
var timer = 500;

//how much food you get each time
var foodPerCycle = 0;
var powerPerCycle = 0;
var materialPerCycle = 0;

var populationMax = 0;
var baseLvl = 1;
var farmLvl = 1;
var powerplantLvl = 0;
var mineLvl = 1;

//how many people are at what thing
var farmers = 0;
var miners = 0;
var electricians = 0;
var guards = population;


//display variables
var scaleMod;
var displayCut;
var truetrueMouseX = 0;
var truetrueMouseY = 0;




////////////////////////////////////////////////BASE GRAPHICS////////////////////////////////////////////////

var base1 = function(base1X, base1Y, base1Size) {



  push();
  translate(base1X, base1Y);
  scale(base1Size);


  //dirt hut
  stroke(0, 128, 6);
  strokeWeight(2);
  fill(184, 123, 0);
  arc(0, 0, 50, 40, 180, 0);
  arc(0, 0, 50, 10, 0, 180);
  fill(0);
  arc(0, 4, 10, 20, 180, 0);



  //campfire

  //rocks
  for (var b11 = 0; b11 < 4; b11++) {
    push();
    translate(-10, 3);
    rotate(70 - b11 * 45);
    fill(150);
    stroke(100);
    strokeWeight(1);
    ellipse(0, 4, 3, 3);
    pop();
  }



  //fire
  fill(255, 50 + random(0, 100), 50);
  noStroke();
  ellipse(-10, 3, 5 + random(-1, 1), 5 + random(-1, 1));
  triangle(-10 + random(-2, 2), -3 + random(-2, 2), -12, 3, -8, 3);
  pop();
};

var base2 = function(base2X, base2Y, base2Size) {
  push();
  translate(base2X, base2Y);
  scale(base2Size);


  //tarp and tarp shadow
  noStroke();
  fill(155, 142, 101);
  triangle(0, 0, -15, 15, 15, 15);
  fill(50);
  ellipse(0, 15, 25, 7);



  //wooden poles
  for (var b21 = 0; b21 < 4; b21++) {
    push();
    rotate(45 - b21 * 10);
    stroke(112, 84, 0);
    strokeWeight(3);
    line(0, -3, 0, 20);
    stroke(168, 126, 0);
    strokeWeight(2);
    line(0, -3, 0, 20);
    pop();

    push();
    rotate(-45 + b21 * 10);
    stroke(112, 84, 0);
    strokeWeight(3);
    line(0, -3, 0, 20);
    stroke(168, 126, 0);
    strokeWeight(2);
    line(0, -3, 0, 20);
    pop();
  }
  //tarp 
  fill(255, 242, 201);
  noStroke();
  quad(-4, 2, -0.5, 6, -3, 18, -14, 12);
  quad(4, 2, 0.5, 6, 3, 18, 14, 12);
  pop();



};

var base3 = function(base3X, base3Y, base3Size) {
  push();
  translate(base3X, base3Y);
  scale(base3Size);
  noStroke();
  fill(163, 122, 0);
  rect(-12, 5, 24, 25);
  fill(0);
  rect(-8, 15, 16, 15);
  fill(200, 0, 0);
  quad(-15, 0, 15, -10, 15, 8, -15, 18);
  fill(150, 0, 0);
  quad(-15, 0, 15, -10, 15, 5, -15, 15);



  pop();
};

var base4 = function(base4X, base4Y, base4Size) {
  push();
  translate(base4X, base4Y);
  noStroke();
  scale(base4Size);


  //wall
  fill(122, 14, 0);
  rect(-15, 3, 30, 30);



  //roof
  fill(80);
  quad(-20, 5, -20, 15, 0, 5, 0, -5);
  quad(20, 5, 20, 15, 0, 5, 0, -5);

  fill(50);
  quad(-20, 13, -20, 15, 0, 5, 0, 3);
  quad(20, 13, 20, 15, 0, 5, 0, 3);

  //door
  fill(77, 31, 0);
  rect(-4, 19, 8, 14);



  //windows
  strokeWeight(1);
  stroke(97, 81, 0);
  fill(94, 215, 255);
  rect(-13, 20, 7, 7, 2);
  rect(6, 20, 7, 7, 2);
  line(-9.5, 20, -9.5, 27);
  line(9.5, 20, 9.5, 27);

  line(-13, 23.5, -6, 23.5);
  line(13, 23.5, 6, 23.5);
  pop();
};

var base5 = function(base5X, base5Y, base5Size) {
  push();
  translate(base5X, base5Y);
  scale(base5Size);
  noStroke();


  //base of the apartment
  fill(100);
  rect(-25, 0, 50, 10);
  fill(80);
  rect(-25, -20, 50, 20);


  //roof of the apartment
  fill(180);
  rect(-20, -110, 40, 20);



  //apartment
  fill(150);
  rect(-20, -90, 40, 85);


  //windows
  noStroke();
  for (var b51 = 0; b51 < 6; b51++) {
    for (var b52 = 0; b52 < 3; b52++) {
      fill(181, 253, 255);
      rect(-16 + b52 * 12, b51 * 12 - 86, 8, 8);
      fill(80);
      rect(-17 + b52 * 12, b51 * 12 - 79, 10, 2);
    }
  }



  pop();

};

var base6 = function(base6X, base6Y, base6Size) {
  push();
  translate(base6X, base6Y);
  scale(base6Size);
  noStroke();


  //body


  fill(150);
  rect(-20, -20, 40, 20);
  fill(50);
  rect(-20, 0, 40, 100);

  //roof things
  fill(100);
  rect(-10, -18, 20, 10);
  fill(50);
  rect(-10, -8, 20, 3);

  fill(200);
  rect(-1, -42, 2, 30, 2);


  //glass
  for (var b61 = 0; b61 < 4; b61++) {
    for (var b62 = 0; b62 < 10; b62++) {
      fill(0, 90, 168);
      rect(-20 + b61 * 10, 0 + b62 * 10, 9, 9);


    }


  }

  pop();
};

var base7 = function(base7X, base7Y, base7Size) {
  push();
  translate(base7X, base7Y);
  scale(base7Size);
  noStroke();

  //right side

  //body  
  fill(200);
  quad(6, -2, 12, -2, 12, -37, 6, -42);

  fill(150);
  quad(6, -2, 12, -2, 12, -33, 6, -38);

  //blue glowing windows  
  for (var b71 = 0; b71 < 8; b71++) {
    stroke(0, 255, 255);
    strokeWeight(1);
    line(7, -4 - b71 * 4, 11, -4 - b71 * 4);

  }


  //left side  

  noStroke();

  //body  
  fill(250);
  quad(-6, 0, 6, 0, 6, -62, -6, -47);

  fill(230);
  quad(-6, 0, 6, 0, 6, -50, -6, -35);

  stroke(0);
  strokeWeight(1);
  line(-5.5, -30, -1, -30);
  line(5.5, -33, 1, -33);
  line(-1, -30, 1, -33);


  pop();
};

var base7capital = function(base7CapX, base7CapY, base7CapSize) {
  push();
  translate(base7CapX, base7CapY);
  scale(base7CapSize);

  //pyramid

  //left side of pyramid

  stroke(0);
  strokeWeight(1);
  fill(30);
  quad(-20, 44, -1, 37, -1, 28, -20, 35);

  stroke(0, 255, 255);
  strokeWeight(1);
  fill(30);
  line(-11, 37, 0, 33);

  beginShape();
  vertex(-4, 22);
  vertex(-14, 36);
  vertex(-4, 39);
  vertex(-4, 46);
  vertex(-25, 39);
  vertex(-4, 9);
  endShape(CLOSE);
  stroke(0, 255, 255);
  line(-21, 38, -14, 36);
  stroke(0);
  fill(250);

  stroke(220);
  beginShape();
  vertex(0, 0);
  vertex(-30, 41);
  vertex(0, 51);
  beginContour();
  vertex(-21, 38);
  vertex(-5, 16);
  vertex(-5, 43);
  endContour();
  endShape(CLOSE);

  line(0, 0, -5, 16);
  line(-30, 41, -21, 38);
  line(0, 51, -5, 43);

  //right side of pyramid

  stroke(0);
  strokeWeight(1);
  fill(30);
  quad(20, 44, 1, 37, 1, 28, 20, 35);

  stroke(0, 255, 255);
  strokeWeight(1);
  fill(30);
  line(11, 37, 0, 33);

  beginShape();
  vertex(4, 22);
  vertex(14, 36);
  vertex(4, 39);
  vertex(4, 46);
  vertex(25, 39);
  vertex(4, 9);
  endShape(CLOSE);
  stroke(0, 255, 255);
  line(21, 38, 14, 36);
  stroke(0);

  stroke(220);
  fill(250);
  beginShape();
  vertex(0, 0);
  vertex(30, 41);
  vertex(0, 51);
  beginContour();
  vertex(21, 38);
  vertex(5, 16);
  vertex(5, 43);
  endContour();
  endShape(CLOSE);

  line(0, 0, 5, 16);
  line(30, 41, 21, 38);
  line(0, 51, 5, 43);

  //beacon

  //glowing orb
  for (var bc71 = 0; bc71 < 10; bc71++) {

    noStroke();
    fill(0, 255, 255, 50);
    ellipse(0, -5, bc71 + random(0, 2), bc71 + random(0, 2));

    //halo
    stroke(0, 255, 255, 30);
    strokeWeight(bc71 / 5 + random(-1, 1));
    noFill();
    arc(0, -5, 20, 3, 180, 0);
    strokeWeight(bc71 / 2 + random(0, 1));
    line(0, -5, 0, -9999);
  }

  noStroke();
  fill(200, 255, 255);
  ellipse(0, -5, 5 + random(0, 2), 5 + random(0, 2));
  stroke(200, 255, 255);
  strokeWeight(1 + random(0, 1));
  line(0, -5, 0, -9999);

  //halo
  for (bc71 = 0; bc71 < 10; bc71++) {
    stroke(0, 255, 255, 30);
    strokeWeight(bc71 / 5 + random(-1, 1));
    noFill();
    arc(0, -5, 20, 3, 0, 180);
  }
  pop();
}

////////////////////////////////////////////////FARM GRAPHICS////////////////////////////////////////////////

var farm1 = function(farm1X, farm1Y, farm1Size) {
  push();
  translate(farm1X, farm1Y);
  scale(farm1Size);


  //dirt
  stroke(150, 86, 37);
  strokeWeight(2);
  fill(120, 56, 7);
  rect(-20, -10, 40, 15, 5);


  //crops
  for (var f11 = 0; f11 < 5; f11++) {
    for (var f12 = 0; f12 < 2; f12++) {
      push();
      translate(f11 * 6 - 13.5, f12 * 5 - 4);
      stroke(100, 36, 0);
      noFill();
      strokeWeight(1);
      arc(0, 0, 3, 3, 180, 0);
      arc(3, 0, 3, 3, 180, 0);
      stroke(0, 200, 0);
      line(1.5, -2, 1.5, -6);

      stroke(255, 216, 20);
      strokeWeight(2);
      line(1.5, -5, 1.5, -8);

      pop();
    }
  }


  pop();
};

var farm2 = function(farm2X, farm2Y, farm2Size) {
  push();
  translate(farm2X, farm2Y);
  scale(farm2Size);


  //dirt
  fill(82, 22, 0);
  stroke(107, 50, 0);
  strokeWeight(1);
  rect(-17.5, -10, 35, 20, 3);

  //bushs
  for (var f21 = 0; f21 < 5; f21++) {
    for (var f22 = 0; f22 < 4; f22++) {
      push();
      translate(-13 + f21 * 6.5, -6 + f22 * 4);




      //bush graphics
      for (var f23 = 0; f23 < 4; f23++) {
        push();
        rotate(f23 * 50 - 75);
        fill(0, 200, 0);
        noStroke();
        ellipse(0, -1, 2, 3);

        pop();
      }

      pop();
    }
  }


  pop();
};

var farm3 = function(farm3X, farm3Y, farm3Size) {
  push();
  translate(farm3X, farm3Y);
  scale(farm3Size);




  //field
  fill(71, 17, 0);
  stroke(82, 45, 0);
  strokeWeight(2);
  rect(14, -20, 30, 40, 5);

  for (var f31 = 0; f31 < 4; f31++) {
    for (var f32 = 0; f32 < 10; f32++) {
      push();
      translate(-10 + f31 * 6, -13 + f32 * 3);
      //green leaves
      fill(0, 200, 0);
      noStroke();
      beginShape();
      vertex(29, 0);
      vertex(31, 0);
      vertex(32, -5);
      vertex(31, -3);
      vertex(30, -7);
      vertex(29, -3);
      vertex(28, -5);
      endShape(CLOSE);
      //pink thing
      fill(191, 0, 108);
      noStroke();
      arc(30, 0, 5, 5, 180, 0);
      pop();
    }
  }
  //barn


  //ground
  fill(87, 61, 10);
  noStroke();
  rect(-12.5, -10, 25, 12, 2);






  //back gate
  strokeWeight(1);
  stroke(153, 110, 23);
  line(-10, -12, 10, -12);
  line(-10, -9, 10, -9);
  line(-10, -12, 10, -9);



  //hay bale
  noStroke();
  fill(151, 135, 0);
  ellipse(5, -5, 7, 7);
  ellipse(5, -4, 7, 7);
  fill(191, 175, 4);
  ellipse(5, -3, 7, 7);



  stroke(153, 110, 23);

  //front gate
  line(-10, -6, 10, -6);
  line(-10, -1, 10, -1);
  line(10, -6, -10, -1);

  //wooden poles

  strokeWeight(2);
  line(-10, -20, -10, 0);
  line(10, -20, 10, 0);
  line(-10, -14, 10, -14);



  //roof
  noStroke();
  fill(150, 0, 0);

  quad(-15, -10, -15, -25, 0, -30, 0, -15);
  quad(15, -10, 15, -25, 0, -30, 0, -15);

  fill(100, 0, 0);
  quad(-15, -10, -15, -12, 0, -17, 0, -15);
  quad(15, -10, 15, -12, 0, -17, 0, -15);













  pop();
};

var farm4 = function(farm4X, farm4Y, farm4Size) {
  push();
  translate(farm4X, farm4Y);
  scale(farm4Size);


  //barn


  //walls
  noStroke();
  fill(148, 0, 0);
  rect(-15, 0.5, 30, 30);




  //doors
  stroke(200);
  strokeWeight(1);
  line(-7, 18, -7, 30);
  line(7, 18, 7, 30);
  line(0, 18, 0, 30);
  line(-7, 30, 7, 30);
  line(-7, 18, 7, 18);
  line(-7, 18, 0, 30);
  line(7, 18, 0, 30);
  line(0, 18, -7, 30);
  line(0, 18, 7, 30);


  //roof
  line(17, 14.2, 10, 8);
  line(-17, 14.2, -10, 8);
  line(10, 8, 0, 5);
  line(-10, 8, 0, 5);

  noStroke();
  fill(80);

  beginShape();
  vertex(-18, 15);
  vertex(-18, -5);
  vertex(-10, -12);
  vertex(0, -15);
  vertex(10, -12);
  vertex(18, -5);
  vertex(18, 15);
  vertex(10, 8);
  vertex(0, 5);
  vertex(-10, 8);
  endShape(CLOSE);


  //silo
  noStroke();
  fill(194, 161, 126);
  ellipse(29, 25, 20, 10);
  rect(19, 0, 20, 25);


  fill(200);
  ellipse(29, 0, 20, 10);
  arc(29, 0, 20, 20, 180, 0);

  noFill();
  strokeWeight(0.5);
  stroke(0);
  arc(29, 0, 20, 20, 180, 0);
  arc(29, 2.7, 15, 25, 180, 0);
  arc(29, 5, 5, 29, 180, 0);

  pop();
};

var farm5 = function(farm5X, farm5Y, farm5Size) {
  push();
  translate(farm5X, farm5Y);
  scale(farm5Size);

  //garden
  fill(89, 47, 11);
  stroke(112, 54, 6);
  strokeWeight(1);
  rect(-10, -19, 20, 17, 3);


  for (var f51 = 0; f51 < 3; f51++) {
    for (var f52 = 0; f52 < 3; f52++) {
      push();
      translate(-7 + f51 * 6, -24 + f52 * 6);
      //stems
      stroke(0, 200, 0);
      strokeWeight(1);
      line(0, 0, 0, 7);
      for (var f53 = 0; f53 < 3; f53++) {
        //berrys
        fill(255, 0, 0);
        noStroke();
        translate(sin(f53 * 200), 1 + f53);
        ellipse(0, 0, 1.5, 1.5);



      }




      pop();
    }
  }



  //greenhouse
  strokeWeight(1);
  stroke(200);
  fill(200, 200, 200, 100);

  //front and back walls
  arc(0, 0, 25, 25, 180, 0);
  arc(0, -20, 25, 25, 180, 0);

  //covering
  for (var f54 = 0; f54 < 20; f54++) {
    noFill();
    stroke(200, 200, 200, 100);
    arc(0, -f54, 25, 25, 180, 0);
  }





  pop();
};

var farm6 = function(farm6X, farm6Y, farm6Size) {
  push();
  translate(farm6X, farm6Y);
  scale(farm6Size);
  for (var f61 = 0; f61 < 4; f61++) {
    push();
    translate(0, -f61 * 10);
    //base
    fill(250);
    noStroke();
    ellipse(0, 0, 20, 8);
    rect(-10, -4, 20, 4);
    fill(50);
    ellipse(0, -4, 20, 8);

    //plants
    for (var f63 = 0; f63 < 5; f63++) {
      push();
      translate(f63 * 3 - 6, 0);
      stroke(0, 200, 0);
      strokeWeight(1);
      line(0, -4, 0, -5);
      noStroke();
      fill(255, 0, 0);
      ellipse(0, -5, 2, 2);

      pop();
    }

    //glass
    for (var f62 = 0; f62 < 5; f62++) {
      fill(0, 255, 255, 50);
      noStroke();
      ellipse(0, -4 - f62, 20, 8);
    }
    pop();
  }
  noStroke();
  fill(250);
  ellipse(0, -40, 20, 8);



  pop();
};

////////////////////////////////////////////POWER PLANT GRAPHICS/////////////////////////////////////////////

var powerP1 = function(powerP1X, powerP1Y, powerP1Size) {
  push();
  translate(powerP1X, powerP1Y);
  scale(powerP1Size);
  //building
  fill(100);
  noStroke();
  rect(-12.5, 0, 25, 8);
  fill(120);
  rect(-12.5, -10, 25, 10);

  //funnels
  fill(80);
  //left funnel
  ellipse(-6, -5, 8, 4);
  quad(-10, -5, -8, -20, -4, -20, -2, -5);
  fill(50);
  ellipse(-6, -20, 4, 2);
  //right funnel
  fill(80);
  ellipse(6, -5, 8, 4);
  quad(10, -5, 8, -20, 4, -20, 2, -5);
  fill(50);
  ellipse(6, -20, 4, 2);


  //smoke
  for (var pP1 = 0; pP1 < random(5, 10); pP1++) {
    fill(0, 0, 0, random(0, 200));
    ellipse(-6 + sin(pP1 * random(0, 255)) + random(-1, 1), -22 - pP1 * 2, 3 + random(-1, 1), 3 + random(-1, 1));
  }
  for (var pP2 = 0; pP2 < random(5, 10); pP2++) {
    fill(0, 0, 0, random(0, 200));
    ellipse(6 + sin(pP2 * random(0, 255)) + random(-1, 1), -22 - pP2 * 2, 3 + random(-1, 1), 3 + random(-1, 1));
  }


  pop();
};

var powerP2 = function(powerP2X, powerP2Y, powerP2Size) { //solar panel
  push();
  translate(powerP2X, powerP2Y);
  scale(powerP2Size);
  //base of the panels
  fill(200);
  quad(-7, 11, 7, 6, 7, 4, -7, 9);
  fill(250);
  quad(-7, 0, 7, -5, 7, 5, -7, 10);

  //blue circles on the panel
  for (var pP21 = 0; pP21 < 7; pP21++) {
    for (var pP22 = 0; pP22 < 4; pP22++) {
      fill(0, 24, 158);
      push();
      translate(-5.7, 0.9 + pP22 * 2);
      //rotates the circles at the proper angle relative to the quadrilateral's top edge
      rotate(-19.6539186875);
      ellipse(pP21 * 2, 0, 2, 2);
      pop();
    }
  }
  pop();
};

var turbineRot = 0;
var powerP3 = function(powerP3X, powerP3Y, powerP3Size) { //wind turbine
  push();
  translate(powerP3X, powerP3Y);
  scale(powerP3Size);

  //base of wind turbine
  noStroke();
  fill(94);
  ellipse(0, 0, 14, 5);
  rect(-7, -3, 14, 3);
  fill(120);
  ellipse(0, -3, 14, 5);

  //pillar
  fill(200);
  ellipse(0, -3, 8, 2);
  quad(-4, -3, 4, -3, 2, -60, -2, -60);

  //blade
  for (var pP31 = 0; pP31 < 3; pP31++) {
    push();
    translate(0, -60);
    rotate(pP31 * 120 + turbineRot);
    translate(0, 60);
    fill(230);
    ellipse(0, -60, 6, 6);
    triangle(0, -60, -30, -60, -3, -64);
    pop();
  }

  pop();
};

var powerP4 = function(powerP4X, powerP4Y, powerP4Size) { //nuclear power plant
  push();
  translate(powerP4X, powerP4Y);
  scale(powerP4Size);


  //reactor steam exhaust
  stroke(120);
  strokeWeight(1);
  noFill();
  arc(-13, 0, 10, 30, 290, 90);
  arc(13, 0, 10, 30, 90, 250);
  noStroke();
  fill(120);
  quad(-9, -10, -8, 3, 8, 3, 9, -10);
  quad(-8, 3, 8, 3, 10, 13, -10, 13);
  ellipse(0, 15, 26, 7);
  fill(50);
  ellipse(0, -10, 19.5, 5);

  //radioactive symbol

  fill(50);
  noStroke();
  ellipse(0, 4, 12, 12);

  fill(255, 255, 0);
  for (var pP41 = 0; pP41 < 3; pP41++) {


    push();
    translate(0, 4);
    rotate(pP41 * 120);
    beginShape();
    vertex(0, 0);
    vertex(5.5, -3);
    vertex(5.5, 3);
    endShape(CLOSE);
    pop();
  }
  noFill();
  strokeWeight(1);
  stroke(50);
  ellipse(0, 4, 1, 1);
  ellipse(0, 4, 12, 12);




  stroke(50);
  strokeWeight(2);
  line(-15, 9, -9, 9);


  noStroke();
  fill(150);
  rect(-40, 0, 25, 10);
  fill(100);
  rect(-40, 7, 25, 10);

  //smoke
  for (var pP42 = 0; pP42 < 30; pP42++) {
    fill(250, 250, 250, 200 - pP42 * 5);
    ellipse(random(-10 - pP42, 10 + pP42), -18 - pP42 * 2, 17, 17);



  }






  pop();
};

var orbRot = 0;
var powerP5 = function(powerP5X, powerP5Y, powerP5Size) {

  push();
  translate(powerP5X, powerP5Y);
  scale(powerP5Size);


  //thing that connects the top and bottom
  noFill();
  stroke(50);
  strokeWeight(1);
  arc(-10, -10, 20, 30, 90, 270);
  arc(10, -10, 20, 30, 270, 90);

  //bottom platform
  noStroke();
  fill(250);
  beginShape();
  vertex(-10, 0);
  vertex(-12, 4);
  vertex(12, 4);
  vertex(10, 0);
  endShape(CLOSE);
  ellipse(0, 4, 24, 10);
  fill(50);
  ellipse(0, 0, 20, 8);


  //energy orb


  noStroke();
  //spinning thing around the orb
  for (var pP52 = 0; pP52 < 40; pP52++) {
    push();
    fill(0, 255, 255, 100);
    translate(0, -10);
    rotate(pP52 * 49);
    rotate(orbRot);
    translate(pP52 / 5, 0);
    ellipse(0, 0, 1, 1 + pP52 / 10);
    pop();
  }

  orbRot += 15;
  if (orbRot > 360) {
    orbRot = 0;
  }


  //orb
  noStroke();
  fill(255);
  ellipse(0, -10, 5, 5);

  for (var pP51 = 0; pP51 < 10; pP51++) {
    fill(0, 255, 255, 50);
    ellipse(0, -10, pP51, pP51);
  }
  fill(255, 255, 255, 140);
  ellipse(0, -10, 5, 5);



  //top platform
  noStroke();
  fill(250);
  beginShape();
  vertex(-10, -20);
  vertex(-12, -24);
  vertex(12, -24);
  vertex(10, -20);
  endShape(CLOSE);

  fill(250);
  ellipse(0, -20, 20, 8);
  fill(50);
  ellipse(0, -24, 24, 10);

  //another thing that holds the top and bottom together
  stroke(50);
  strokeWeight(1);
  line(0, 8.5, 0, -20);

  pop();
};

////////////////////////////////////////////////MINE GRAPHICS////////////////////////////////////////////////

var leafX = [];
var leafY = [];
var mine1Rot = 0;
var mine1Swing = true;
var mine1 = function(mine1X, mine1Y, mine1Size) {
  push();
  translate(mine1X, mine1Y);
  scale(mine1Size);

  //trunk
  noStroke();
  fill(145, 80, 0);
  quad(-5, 0, 5, 0, 4, -50, -4, -50);
  ellipse(0, 0, 10, 5);

  //leaves
  for (var m11 = 0; m11 < 10; m11++) {
    leafX.push(random(-20, 20));
    leafY.push(random(-40, -60));
    fill(30, 148, 0);
    noStroke();
    ellipse(leafX[m11], leafY[m11], 20, 20);
  }
  fill(30, 148, 0);
  ellipse(0, -50, 40, 20);




  //guy with axe
  noStroke();
  fill(0);
  ellipse(15, -15, 5, 5);
  stroke(0);
  strokeWeight(1);
  line(15, -15, 15, -8);
  line(15, -8, 13, 0);
  line(15, -8, 17, 0);

  //swinging arm
  push();
  translate(15, -12);
  rotate(mine1Rot);
  translate(-15, 12);
  stroke(0);
  strokeWeight(1);
  line(15, -12, 8, -12);

  //axe
  stroke(133, 62, 0);
  line(8.5, -11.5, 8.5, -20);
  noStroke();
  fill(120);
  quad(8, -20, 8, -17, 6, -16, 6, -21);

  pop();





  pop();
};

var mine2Rot = 0;
var mine2Swing = 0;
var mine2 = function(mine2X, mine2Y, mine2Size) {
  push();
  translate(mine2X, mine2Y);
  scale(mine2Size);
  //rock
  noStroke();
  fill(138);
  beginShape();
  vertex(13, 7);
  vertex(10, 14);
  vertex(4, 15);
  vertex(-10, 11);
  vertex(-7, 4);
  vertex(0, -3);
  vertex(8, 0);
  endShape(CLOSE);

  //guy with pickaxe
  noStroke();
  fill(0);
  ellipse(20, -5, 5, 5);
  stroke(0);
  strokeWeight(1);
  line(20, -5, 20, 3);
  line(20, 3, 18, 13);
  line(20, 3, 22, 13);

  //rotating arm with pickaxe
  push();
  translate(20, -2);
  rotate(mine2Rot);
  translate(-20, 2);
  stroke(0);
  strokeWeight(1);
  line(20, -2, 13, -2);
  stroke(107, 68, 0);
  line(13.5, -1.5, 13.5, -12);
  stroke(190);
  noFill();
  arc(13.5, -2, 20, 20, 240, -60);

  pop();
  pop();
};

var leafX2 = [];
var leafY2 = [];
var mine2Rot = 0;
var mine3 = function(mine3X, mine3Y, mine3Size) {
  push();
  translate(mine3X, mine3Y);
  scale(mine3Size);

  //tree

  //trunk
  noStroke();
  fill(145, 80, 0);
  quad(-5, 0, 5, 0, 4, -50, -4, -50);
  ellipse(0, 0, 10, 5);

  //leaves
  for (var m31 = 0; m31 < 10; m31++) {
    leafX2.push(random(-20, 20));
    leafY2.push(random(-40, -60));
    fill(30, 148, 0);
    noStroke();
    ellipse(leafX2[m31], leafY2[m31], 20, 20);
  }
  fill(30, 148, 0);
  ellipse(0, -50, 40, 20);

  //guy with chainsaw

  noStroke();
  fill(0);
  ellipse(17, -15, 5, 5);
  stroke(0);
  strokeWeight(1);
  line(17, -15, 17, -8);
  line(17, -8, 15, 0);
  line(17, -8, 19, 0);
  line(17, -12, 12, -10);
  line(17, -12, 15, -8);
  //chainsaw
  //blade
  fill(219, 219, 219);
  stroke(196);
  strokeWeight(1);
  rect(0, -8, 10, 2, 2);


  stroke(50);
  strokeWeight(1);
  noFill();
  arc(14, -7.5, 3, 3, 270, 90);
  line(10, -8, 12, -11);
  noStroke();
  fill(255, 170, 0);
  rect(9, -10, 5, 5, 1);

  pop();
};

var randomX = 0;
var randomY = 0;
var mine4 = function(mine4X, mine4Y, mine4Size) {
  randomX = random(-1, 1);
  randomY = random(-1, 1);
  push();
  translate(mine4X, mine4Y);
  scale(mine4Size);
  //guy
  noStroke();
  fill(0);
  ellipse(0, -10, 5, 5);
  stroke(0);
  strokeWeight(1);
  line(0, 0, 0, -10);
  line(0, 0, -2, 10);
  line(0, 0, 2, 10);
  line(0, -8, -7 + randomX, -6 + randomY);
  line(0, -8, -2 + randomX, -4 + randomY);
  //jack hammer
  push();
  translate(-6 + random(-1, 1), -6 + random(-1, 1));

  rotate(20);
  stroke(60);
  strokeWeight(1);
  line(-2, 1, 5, 1);
  noStroke();
  fill(120);
  rect(1, 7, 1, 6);

  fill(255, 119, 0);
  rect(0, 0, 3, 9, 2);


  pop();



  //rock
  fill(100);
  noStroke();
  beginShape();
  vertex(-10, 2);
  vertex(-15, 5);
  vertex(-18, 9);
  vertex(-13, 13);
  vertex(-5, 11);
  vertex(-7, 5);
  endShape(CLOSE);




  pop();
};

var mine6Rot = 0;
var mine6Dig = true;
var mine5 = function(mine5X, mine5Y, mine5Size) {
  push();
  translate(mine5X, mine5Y);
  scale(mine5Size);

  //the dirt
  fill(92, 49, 17);
  noStroke();
  ellipse(0, 0, 100, 40);

  //thing under the body
  fill(60);
  noStroke();
  rect(9, -6, 10, 10);
  //treads
  stroke(70);
  strokeWeight(1);
  fill(100);
  rect(0, -2, 25, 5, 2);
  rect(0, 0, 25, 5, 2);
  rect(0, -12, 25, 5, 2);
  rect(0, -10, 25, 5, 2);
  for (var m51 = 0; m51 < 6; m51++) {
    ellipse(2.5 + m51 * 4, 2.5, 3, 3);
  }
  fill(255, 221, 0);
  beginShape();
  vertex(3, -14);
  vertex(27, -14);
  vertex(27, -23);
  vertex(15, -23);
  vertex(10, -17);
  vertex(3, -17);
  endShape(CLOSE);

  stroke(70);
  strokeWeight(1);
  fill(255, 221, 0);
  rect(3, -17, 8, 12);



  //digging part
  strokeWeight(6);
  stroke(200, 175, 0);
  line(10, -20, 0, -35);
  line(-26, -38, 0, -35);

  stroke(225, 200, 0);
  line(10, -15, 0, -30);
  line(-26, -33, 0, -30);


  push();
  translate(-26, -33);
  rotate(mine6Rot);
  stroke(200, 175, 0);
  line(0, -6, 0, 21);
  stroke(225, 200, 0);
  line(0, -3, 0, 21);


  push();
  translate(4, 30);
  rotate(mine6Rot * 2);
  noStroke();
  fill(50);
  arc(0, 0, 15, 15, 90, -90);
  rect(-7.5, -1, 7, 7);
  push();
  stroke(225, 200, 0);
  strokeWeight(6);

  rotate(-mine6Rot * 1.2);
  line(-3, -6, -3, -8);
  pop();
  noStroke();
  fill(80);
  arc(0, 5, 15, 15, 90, -90);
  pop();
  pop();









  //cab
  strokeWeight(1);
  stroke(70);
  fill(0, 183, 196);
  quad(7, -25, 13, -25, 15, -11, 4, -11);
  quad(7, -20, 13, -20, 15, -6, 4, -6);

  //body
  stroke(70);
  strokeWeight(1);
  fill(255, 221, 0);
  beginShape();
  vertex(3, -4);
  vertex(27, -4);
  vertex(27, -13);
  vertex(15, -13);
  vertex(10, -7);
  vertex(3, -7);
  endShape(CLOSE);
  rect(15, -23, 12, 10);



  pop();
};

var oilRot = 0;
var oilDown = false;
var oil2Rot = 70;
//the new coordinates after you rotate the motor
var mine6x2 = 0;
var mine6y2 = 0;
//the point of rotation for the motor
var pX = 14;
var pY = 10;
//new coordinates after you rotate the drill
var mine6x3 = 0;
var mine6y3 = 0;
var mine6x4 = 0;
var mine6y4 = 0;
var mine6 = function(mine6X, mine6Y, mine6Size) {
  push();
  translate(mine6X, mine6Y);
  scale(mine6Size);

  //drill pipe
  stroke(50);
  strokeWeight(1);
  line(-12, 0, -12, 20);
  fill(100);
  noStroke();
  rect(-13, 9 - oilRot / 10, 2, 2);
  //beams that hold up the thing
  stroke(150);
  strokeWeight(2);
  line(0, 0, -5, 20);
  line(0, 0, 5, 20);

  //pump motor
  noStroke();
  fill(138, 120, 88);
  rect(10, 8, 10, 13);
  push();
  translate(14, 10);
  rotate(oil2Rot);
  stroke(71, 64, 53);
  strokeWeight(3);
  line(0, 0, 0, 10);


  pop();


  //the pump
  push();
  rotate(oilRot);
  translate(-12.5, -4);
  noStroke();
  fill(100);
  rect(0, 0, 25, 4, 2);
  arc(4, 4, 10, 15, 90, 270);
  pop();


  //part that attachs motor to pump
  fill(0);
  stroke(0);
  line(mine6x2, mine6y2, mine6x3, mine6y3);
  pop();
};

var mine7 = function(mine7X, mine7Y, mine7Size) {
  push();
  translate(mine7X, mine7Y);
  scale(mine7Size);


  //beams
  noFill();
  strokeWeight(7);
  stroke(0, 255, 255);
  ellipse(0, 10, 49, 49);
  stroke(50);

  ellipse(0, 10, 50, 50);
  strokeWeight(2);
  noStroke();

  //laser cannon
  fill(0, 255, 255);
  rect(-5, 0, 10, 45);
  ellipse(-3, 45, 4, 4);
  ellipse(3, 45, 4, 4);
  fill(50);
  rect(-4, 0, 8, 50);
  ellipse(0, 50, 8, 3);
  fill(0, 255, 255);
  rect(-1, 0, 2, 46);
  ellipse(0, 46, 2, 2);

  //bottom part
  noStroke();
  fill(230);
  quad(-20, 0, 20, 0, 15, 15, -15, 15);
  ellipse(0, 15, 30, 5.5);


  //dome on top
  fill(250);
  ellipse(0, 0, 80, 15);
  arc(0, 0, 80, 50, 180, 0);

  //plasma laser
  for (var m71 = 0; m71 < 10; m71++) {
    stroke(0, 255, 255, 50);
    strokeWeight(m71 + random(-3, 3));
    line(0, 60, 0, 270);
  }
  noStroke();
  for (var m72 = 0; m72 < 20; m72++) {
    fill(0, 255, 255, 40);
    ellipse(0, 60, m72 + random(-3, 3), m72 + random(-3, 3));

  }
  fill(255);
  ellipse(0, 60, 8 + random(-2, 1), 8 + random(-2, 1));

  for (var m73 = 0; m73 < 10; m73++) {
    noStroke();
    fill(0, 255, 255, 100);
    arc(0, 270, 30 + m73 * 3 + random(-3, 3), 30 + m73 * 3 + random(-3, 3), 180, 0);
    ellipse(0, 270, 30 + m73 * 3 + random(-3, 3), 10 + m73 + random(-3, 3));
    noFill();
    stroke(0, 255, 255, 100);
    strokeWeight(10);

  }





  pop();
};

/////////////////////////////////////////////////CLOUD CODE//////////////////////////////////////////////////

//array for clouds
var Clouds = [];

//cloud object
var cloud = function() {
  this.x = 0;
  this.y = 0;
  this.size = 0;
  this.move = 0;
  this.moveSpeed = 0;
  this.moveLeft = false;
};

//creates a cloud
var makeCloud = function() {
  var cld = new cloud();

  cld.x = random(0, 800);
  cld.y = random(0, 200);
  cld.size = random(0.5, 1);
  cld.move = random(-150, 150);
  cld.moveSpeed = random(0.1, 0.5);
  cld.moveLeft = false;
  Clouds.push(cld);

};

//graphics and movement for the cloud
var drawCloud = function() {



  var cloudi;



  for (cloudi = 0; cloudi < Clouds.length; cloudi++) {

    //graphics for the cloud
    push();
    translate(Clouds[cloudi].x, Clouds[cloudi].y);
    translate(Clouds[cloudi].move, 0);
    scale(Clouds[cloudi].size);
    fill(255, 255, 255);
    noStroke();
    beginShape();
    ellipse(0, -10, 50, 40);
    ellipse(-20, -7, 30, 30);
    ellipse(25, -10, 30, 30);
    ellipse(0, 0, 100, 20);
    endShape(CLOSE);
    pop();


    //movement for the cloud
    if (Clouds[cloudi].move > 150) {
      Clouds[cloudi].moveLeft = true;
    } else if (Clouds[cloudi].move < -150) {
      Clouds[cloudi].moveLeft = false;
    }
    if (Clouds[cloudi].moveLeft === true) {
      Clouds[cloudi].move -= Clouds[cloudi].moveSpeed;
    } else if (Clouds[cloudi].moveLeft === false) {
      Clouds[cloudi].move += Clouds[cloudi].moveSpeed;
    }


  }



};

//all of the cloud graphics
var cloudGraphics = function() {
  drawCloud();

};

///////////////////////////////////////////////WATER/WAVE CODE///////////////////////////////////////////////

//array for the waves
var Waves = [];

//wave object
var wave = function() {
  this.x = 0;
  this.y = 0;
  this.size = 0;
  this.growing = false;

};

//creates a wave
var makeWave = function() {
  var w = new wave();


  w.x = random(0, 800);
  w.y = random(350, 600);
  w.size = random(0, 0.5);
  w.growing = false;
  Waves.push(w);
};

//draws the waves and the scaling of it
var drawWater = function() {
  var h2o;
  for (h2o = 0; h2o < Waves.length; h2o++) {
    push();
    noStroke();
    fill(0);
    translate(Waves[h2o].x, Waves[h2o].y);
    scale(Waves[h2o].size);
    noFill();
    stroke(64, 112, 255);
    strokeWeight(2);
    angleMode(DEGREES);
    arc(-25, -15, 50, 30, 0, 90);
    arc(25, -15, 50, 30, 90, -180);
    pop();
    if (Waves[h2o].size > 0.5) {
      Waves[h2o].growing = false;
    } else if (Waves[h2o].size < 0) {
      Waves[h2o].growing = true;
    }
    if (Waves[h2o].growing === true) {
      Waves[h2o].size += 0.01;
    } else if (Waves[h2o].growing === false) {
      Waves[h2o].size -= 0.01;
    }

  }

};

//all of the water graphics
var waterGraphics = function() {
  fill(0, 90, 245);
  noStroke();
  rectMode(CORNER);
  rect(0, 300, 800, 300);
  drawWater();
};

///////////////////////////////////////////////ISLAND GRAPHICS///////////////////////////////////////////////

var islandGraphics = function(islandX, islandY, islandSize) {
  push();
  translate(islandX, islandY);
  scale(islandSize);
  noStroke();
  strokeWeight(5);
  stroke(0, 153, 255, 100);
  fill(214, 100, 0);



  //the brown part of the island
  beginShape();
  vertex(-315, -35);
  vertex(-316, -23);
  vertex(-325, -17);
  vertex(-316, -9);
  vertex(-313, 3);
  vertex(-298, 5);
  vertex(-276, 15);
  vertex(-265, 30);
  vertex(-239, 27);
  vertex(-215, 39);
  vertex(-166, 41);
  vertex(-189, 4);
  endShape(CLOSE);



  beginShape();
  vertex(-347, 102);
  vertex(-350, 131);
  vertex(-374, 147);
  vertex(-348, 150);
  vertex(-322, 170);
  vertex(-304, 166);
  vertex(-283, 181);
  vertex(-241, 192);
  vertex(-195, 211);
  vertex(-187, 200);
  vertex(-201, 181);
  vertex(-180, 175);
  vertex(-168, 184);
  vertex(-144, 183);
  vertex(-110, 166);
  vertex(-79, 173);
  vertex(-86, 161);
  vertex(-68, 156);
  vertex(-55, 145);
  vertex(-58, 132);
  vertex(-50, 129);
  vertex(-46, 114);
  vertex(-50, 97);
  vertex(-38, 94);
  vertex(-8, 93);
  vertex(5, 99);
  vertex(50, 96);
  vertex(42, 90);
  vertex(67, 92);
  vertex(84, 98);
  vertex(101, 114);
  vertex(103, 104);
  vertex(96, 88);
  vertex(112, 82);
  vertex(138, 83);
  vertex(140, 69);
  vertex(161, 59);
  vertex(185, 60);
  vertex(190, 48);
  vertex(194, 28);
  vertex(203, 24);
  vertex(219, 10);
  vertex(209, 6);
  vertex(197, -10);
  endShape(CLOSE);

  noStroke();
  //green circles at the top of the island
  fill(34, 171, 0);
  ellipse(0, 0, 400, 150);
  ellipse(-200, 100, 300, 125);
  ellipse(-200, -40, 230, 100);

  //green circles for on the island
  fill(0, 189, 0);
  ellipse(-40, 20, 250, 75);
  ellipse(-200, -50, 150, 50);
  ellipse(70, -20, 150, 50);
  ellipse(-250, 100, 165, 55);
  ellipse(-160, 120, 100, 30);
  pop();
};
var islandButtonGraphics = function(isButtonX, isButtonY, isButtonSize, type) {
  push();
  translate(isButtonX, isButtonY);
  scale(isButtonSize);
  noStroke();
  fill(148, 104, 0);
  rect(-40, -10, 80, 20, 5);
  fill(100);
  rect(-20, -10, 40, 20, 5);
  stroke(0);
  strokeWeight(2);
  line(25, 0, 35, 0);
  line(-25, 0, -35, 0);
  line(-30, -5, -30, 5);
  noStroke();
  fill(0);
  textSize(20);
  textAlign(CENTER);
  text(type, 0, 7.5);
  pop();
};

///////////////////////////////////////////MATERIAL ICON GRAPHICS////////////////////////////////////////////

var foodIcon = function(fIconX, fIconY, fIconSize) {
  push();
  translate(fIconX, fIconY);
  scale(fIconSize);
  //bread
  stroke(145, 97, 0);
  strokeWeight(1);
  fill(184, 132, 27);
  ellipse(0, 0, 20, 6);
  arc(0, 0, 20, 12, 180, 0);

  //cracks at the top of bread
  stroke(245, 196, 98);
  strokeWeight(1);
  line(-4, -5, -5, -2);
  line(0, -5.5, -1, -2);
  line(4, -5, 3, -2);
  pop();
};

var powerIcon = function(pIconX, pIconY, pIconSize) {
  push();
  translate(pIconX, pIconY);
  scale(pIconSize);
  stroke(200, 200, 0);
  strokeWeight(1);
  fill(255, 255, 0);
  beginShape();
  vertex(0, -15);
  vertex(-3, 8);
  vertex(0, 3);
  vertex(0, 15);
  vertex(3, -8);
  vertex(0, -3);
  endShape(CLOSE);
  pop();
};

var materialIcon = function(mIconX, mIconY, mIconSize) {
  push();
  translate(mIconX, mIconY);
  scale(mIconSize);
  fill(130);
  strokeWeight(1);
  stroke(100);
  quad(0, -10, 10, -10, 0, 10, -10, 10);
  quad(0, 10, -10, 10, -12, 15, 3, 15);
  quad(3, 15, 0, 10, 10, -10, 12, -3);
  pop();
};

var personIcon = function(pplIconX, pplIconY, pplIconSize) {
  push();
  translate(pplIconX, pplIconY);
  scale(pplIconSize);
  //body
  fill(34, 130, 209);
  stroke(0, 82, 153);
  strokeWeight(1);
  rect(0, -2, 8, 13);
  rect(-8, -2, 8, 13);
  rect(-4, 0, 8, 13);

  //head
  stroke(153, 99, 0);
  strokeWeight(1);
  fill(179, 119, 0);
  ellipse(-5, -2, 10, 10);
  ellipse(5, -2, 10, 10);
  ellipse(0, 0, 10, 10);
  pop();
};

var defenceIcon = function(dIconX, dIconY, dIconSize) {
  push();
  translate(dIconX, dIconY);
  scale(dIconSize);
  fill(100);
  stroke(50);
  strokeWeight(1);
  rect(-10, -10, 20, 10);
  arc(0, -9, 20, 10, 180, 0);
  arc(5, -1, 30, 30, 110, 180);
  arc(-5, -1, 30, 30, 0, 70);
  noStroke();
  fill(50);
  arc(0, -9, 17, 7, 180, 270);
  rect(-8.5, -9, 8.5, 10);
  arc(0, 0, 17, 20, 90, 180);
  pop();
};

var threatIcon = function(tIconX, tIconY, tIconSize) {
  push();
  translate(tIconX, tIconY);
  scale(tIconSize);
  fill(230);
  noStroke();
  ellipse(0, 0, 20, 15);
  rect(-5, 0, 10, 13, 3);
  fill(60);
  ellipse(-4, 0, 5, 5);
  ellipse(4, 0, 5, 5);
  pop();
};

/////////////////////////////////////////////////GAME THINGS/////////////////////////////////////////////////

function setup() {
  // createCanvas(800, 600);

  createCanvas(windowWidth, windowHeight);
  scaleMod = height / 600;
  displayCut = (width - (height * 8 / 6)) / 2;


  //adds the clouds/waves to the array
  for (var wa = 0; wa < 100; wa++) {
    makeWave();
  }
  for (var cl = 0; cl < 20; cl++) {
    makeCloud();
  }


}

///////////////////////////////////////////////////SCENES////////////////////////////////////////////////////

//menu variables
var menuCloudX = [];
var menuCloudY = [];
var menuRock = function(mRockX, mRockY) {
  push();
  translate(mRockX, mRockY);
  strokeWeight(3);
  stroke(100);
  fill(120);
  beginShape();
  vertex(411, 443);
  vertex(367, 458);
  vertex(346, 495);
  vertex(377, 516);
  vertex(408, 521);
  vertex(439, 514);
  vertex(470, 513);
  vertex(450, 469);
  endShape(CLOSE);
  pop();
};
var glowAmount = 0;
var menu = function() {
  angleMode(DEGREES);
  background(31, 177, 255);

  //resets your things

  population = 20;
  threat = 2;
  food = 50;
  timer = 500;
  material = 350;
  energy = 0;
  baseLvl = 1;
  mineLvl = 1;
  farmLvl = 1;
  powerplantLvl = 0;
  guards = 20;
  miners = 0;
  farmers = 0;
  electricians = 0;
  lose = false;
  gettingAttacked = false;
  won = false;
  paused = false;

  //the title of the game/graphics for the title
  for (var menuC = 0; menuC < 50; menuC++) {
    fill(255 - (menuCloudX[menuC] + menuCloudY[menuC]) / 8);
    noStroke();
    menuCloudX.push(random(135, 670));
    menuCloudY.push(random(50, 100));
    ellipse(menuCloudX[menuC], menuCloudY[menuC], 70, 70);
  }

  noStroke();
  fill(4, 55, 209);
  rect(0, 300, 800, 220);

  textSize(70);
  textAlign(CENTER);
  fill(92);
  stroke(122);
  strokeWeight(6);
  text("Island Civilization", 400, 100);



  //island in the distance
  islandGraphics(620, 320, 0.5);


  //the hill
  strokeWeight(5);
  stroke(30, 179, 0);
  fill(26, 143, 0)
  ellipse(400, 600, 1000, 300);

  //the rocks buttons
  menuRock(0, 20);

  //thing that happens when you hover over the play button  
  if (trueMouseX > 355 && trueMouseX < 450 && trueMouseY > 470 && trueMouseY < 530 && glowAmount < 240) {
    glowAmount += 5;
  } else if (glowAmount > 0) {
    glowAmount -= 5;
  }
  for (var gla = 0; gla < glowAmount; gla++) {
    push();
    translate(405, 505);
    rotate(gla * 4);
    translate(0, gla / 8);
    noStroke();
    fill(0, 255, 255);
    ellipse(0, 0, 2, 2);
    pop();
  }


  noStroke();
  fill(70);
  textSize(30);
  text("Play", 405, 515);
  //detection for the buttons
  //play button
  if (mouseIsPressed && trueMouseX > 355 && trueMouseX < 450 && trueMouseY > 470 && trueMouseY < 530) {
    display = "DIFFICULTY";
    mouseOff = false;
  }


};

var upgradeMenu = function() {
  angleMode(DEGREES);
  background(45, 158, 0);
  fill(100);
  strokeWeight(10);
  stroke(70);
  rect(50, 50, 700, 500, 50);
  noStroke();
  fill(120);
  rect(250, 70, 300, 70, 50);
  textAlign(CENTER);
  textSize(50);
  stroke(90);
  strokeWeight(7);
  fill(80);
  text("UPGRADES", 400, 120);
  //button graphics
  for (var upg1 = 0; upg1 < 4; upg1++) {
    push();
    translate(upg1 * 170, 0);
    stroke(46, 153, 0);
    strokeWeight(5);
    fill(61, 204, 0);
    rect(100, 180, 80, 80, 10);
    fill(255, 0, 0);
    noStroke();
    beginShape();
    vertex(140, 190);
    vertex(110, 210);
    vertex(130, 210);
    vertex(125, 250);
    vertex(155, 250);
    vertex(150, 210);
    vertex(170, 210);
    endShape(CLOSE);
    textSize(20);
    fill(0);
    noStroke();
    text("Cost to Upgrade:", 140, 320);
    materialIcon(80, 340, 1.3);
    powerIcon(80, 390, 1.3);


    pop();
  }
  noStroke();
  fill(222);
  textSize(20);
  text("Upgrade Base", 140, 290);
  text("Upgrade Mine", 310, 290);
  text("Upgrade Farm", 480, 290);
  textSize(15);
  text("Upgrade Power Plant", 650, 290);

  //Cost of upgrading
  textSize(20);
  textAlign(LEFT);
  //base cost
  text(100 + baseLvl * baseLvl * baseLvl * 100, 100, 350);
  text((baseLvl - 1) * baseLvl * baseLvl * 100, 100, 400);





  //mine cost
  text(100 + mineLvl * mineLvl * mineLvl * 100, 270, 350);
  text((mineLvl - 1) * mineLvl * mineLvl * 100, 270, 400);





  //farm cost
  text(100 + farmLvl * farmLvl * farmLvl * 100, 440, 350);
  text((farmLvl - 1) * farmLvl * farmLvl * 100, 440, 400);





  //powerplant cost
  text(100 + powerplantLvl * powerplantLvl * powerplantLvl * 100 + 1000, 610, 350);
  text(powerplantLvl * powerplantLvl * powerplantLvl * 200, 610, 400);

  //upgrade button detection
  if (mouseIsPressed && trueMouseY > 180 && trueMouseY < 260) {

    //base button
    if (tutorial === false && trueMouseX > 100 && trueMouseX < 180 && material >= 100 + baseLvl * baseLvl * baseLvl * 100 && energy >= (baseLvl - 1) * baseLvl * baseLvl * 100 && baseLvl < 7 && mouseOff === true) {
      material -= 100 + baseLvl * baseLvl * baseLvl * 100;
      energy -= baseLvl * baseLvl * baseLvl * 100;
      baseLvl++;
      timer = 500;
    }


    //mine button
    if (tutorial === false && trueMouseX > 270 && trueMouseX < 350 && material >= 100 + mineLvl * mineLvl * mineLvl * 100 && energy >= (mineLvl - 1) * mineLvl * mineLvl * 100 && mineLvl < 7 && mouseOff === true) {
      material -= 100 + mineLvl * mineLvl * mineLvl * 100;
      energy -= (mineLvl - 1) * mineLvl * mineLvl * 100;
      mineLvl++;
      timer = 500;
    }


    //farm button
    if (tutorial === false && trueMouseX > 440 && trueMouseX < 520 && material >= 100 + farmLvl * farmLvl * farmLvl * 100 && energy >= (farmLvl - 1) * farmLvl * farmLvl * 100 && farmLvl < 6 && mouseOff === true) {
      material -= 100 + farmLvl * farmLvl * farmLvl * 100;
      energy -= (farmLvl - 1) * farmLvl * farmLvl * 100;
      farmLvl++;
      timer = 500;
    }


    //powerplant button
    if (tutorial === false && trueMouseX > 610 && trueMouseX < 690 && material >= 100 + powerplantLvl * powerplantLvl * powerplantLvl * 100 + 1000 && energy >= powerplantLvl * powerplantLvl * powerplantLvl * 200 && powerplantLvl < 5 && mouseOff === true) {
      material -= 100 + powerplantLvl * powerplantLvl * powerplantLvl * 100 + 1000;
      energy -= powerplantLvl * powerplantLvl * powerplantLvl * 200;
      powerplantLvl++;
      timer = 500;
    }

  }






  //exit button
  stroke(60);
  strokeWeight(2);
  fill(80);
  rect(700, 70, 30, 30, 10);
  stroke(0);
  strokeWeight(4);
  line(707, 77, 723, 93);
  line(707, 93, 723, 77);
  if (tutorial === false && mouseIsPressed && trueMouseX > 700 && trueMouseX < 730 && trueMouseY > 70 && trueMouseY < 100) {
    display = "GAME";
  }


  //item panel
  stroke(184, 116, 0);
  strokeWeight(4);
  fill(204, 136, 0);
  quad(-10, 450, 100, 450, 200, 600, -10, 600);
  rect(-5, 555, 999, 999);
  textSize(25);
  textAlign(LEFT);
  foodIcon(200, 580, 2.5);
  fill(0);
  noStroke();
  text(floor(food), 230, 590);

  powerIcon(380, 575, 1);
  fill(0);
  noStroke();
  text(floor(energy), 390, 590);

  materialIcon(560, 575, 1);
  fill(0);
  noStroke();
  text(floor(material), 575, 590);

  personIcon(20, 575, 1.5);
  fill(0);
  noStroke();
  text(population, 38, 590);
  population = floor(population);

  threatIcon(20, 470, 1.5);
  noStroke();
  fill(0);
  text(floor((threatAmount * 10)) / 10 + "%", 40, 485);
  defenceIcon(20, 525, 1.2);

  noStroke();
  fill(0);
  text(floor(defence), 40, 530);


};

var loseScreen = function() {
  //resets the stuff
  population = 20;
  threat = 2;
  food = 50;
  timer = 500;
  material = 350;
  energy = 0;
  baseLvl = 1;
  mineLvl = 1;
  farmLvl = 1;
  powerplantLvl = 0;
  guards = 20;
  miners = 0;
  farmers = 0;
  electricians = 0;
  lose = false;
  gettingAttacked = false;
  won = false;
  paused = false;
  background(60);
  textAlign(CENTER);
  textSize(50);
  noStroke();
  fill(255);
  text("You Lost", 400, 100);
  textSize(20);
  rect(350, 300, 100, 100, 10);
  fill(0);
  text("MENU", 400, 355);
  //button detection
  if (mouseIsPressed && trueMouseX > 350 && trueMouseX < 450 && trueMouseY > 300 && trueMouseY < 400 && mouseOff === true) {
    display = "MENU";
  }
};

var winScreen = function() {
  background(43, 188, 255);
  textAlign(CENTER);
  textSize(100);
  stroke(204, 163, 0);
  strokeWeight(6);
  fill(255, 200, 0);
  text("You Won", 400, 120);
  textSize(30);
  strokeWeight(2);
  text("Congratulations, you have beaten Island Civilization", 400, 200);

  //buttons
  strokeWeight(5);
  rect(200, 300, 100, 100, 20);
  rect(500, 300, 100, 100, 20);
  fill(255);
  noStroke();
  textSize(20);
  text("Continue", 250, 355);
  text("Menu", 550, 355);
  if (mouseIsPressed && trueMouseY > 300 && trueMouseY < 400) {
    if (trueMouseX > 200 && trueMouseX < 300) {
      display = "GAME";
    }
    if (trueMouseX > 500 && trueMouseX < 600) {
      display = "MENU";
      //resets the things
      population = 20;
      guards = 20;
      miners = 0;
      electricians = 0;
      farmers = 0;
      food = 50;
      material = 350;
      energy = 0;
      threat = 2;
      baseLvl = 1;
      farmLvl = 1;
      powerplantLvl = 0;
      mineLvl = 1;
      gettingAttacked = false;
      won = false;
      lose = false;
      paused = false;
      timer = 500;
    }

  }
};

var game = function() {
  push();
  angleMode(DEGREES);
  //mathematical calculations for the oil well

  //motor
  mine6x2 = ((14 - pX) * cos(oil2Rot)) - ((15 - pY) * sin(oil2Rot)) + pX;
  mine6y2 = ((14 - pX) * sin(oil2Rot)) + ((15 - pY) * cos(oil2Rot)) + pY;

  //drill
  mine6x3 = (11 * cos(oilRot)) - (-2 * sin(oilRot));
  mine6y3 = (11 * sin(oilRot)) + (-2 * cos(oilRot));

  //drill pipe
  mine6x4 = (-12 * cos(oilRot)) - (2 * sin(oilRot));
  mine6y4 = (-12 * sin(oilRot)) + (2 * cos(oilRot));

  //////////////////////////////////////////////GAME GRAPHICS//////////////////////////////////////////////

  background(125, 229, 255);
  waterGraphics();
  cloudGraphics();
  islandGraphics(580, 350, 1);

  ///////////////////////////////////////////PRODUCTION GRAPHICS///////////////////////////////////////////

  //draws the power plants according to the power plant level
  if (powerplantLvl === 1) {
    powerP1(380, 290, 1.2);
  } else if (powerplantLvl === 2) {
    //draws the solar panels in a grid like fashion
    for (var pP23 = 0; pP23 < 9; pP23++) {
      for (var pP24 = 0; pP24 < 5; pP24++) {
        powerP2(320 + pP23 * 15, 275 + pP24 * 10, 1);
      }
    }
  } else if (powerplantLvl === 3) {
    powerP3(440, 300, 1);
    powerP3(380, 300, 1);
    powerP3(320, 300, 1);
    powerP3(350, 310, 1);
    powerP3(410, 310, 1);
    //makes the turbines spin
    turbineRot += 3;
    if (turbineRot > 360) {
      turbineRot = 0;
    }
  } else if (powerplantLvl === 4) {
    powerP4(395, 285, 1);
  } else if (powerplantLvl === 5) {
    powerP5(380, 295, 1.5);
  }

  //draws the farm according to the farm level
  if (farmLvl === 1) {
    farm1(620, 330, 1);
    farm1(670, 340, 1);
    farm1(665, 320, 1);
  } else if (farmLvl === 2) {
    farm2(620, 330, 1);
    farm2(670, 340, 1);
    farm2(665, 315, 1);
  } else if (farmLvl === 3) {
    farm3(610, 340, 0.7);
    farm3(670, 330, 0.7);
  } else if (farmLvl === 4) {
    farm4(610, 310, 1);
    farm2(678, 330, 1.3);
  } else if (farmLvl === 5) {
    farm5(630, 340, 1.2);
    farm5(665, 340, 1.2);
    farm5(700, 340, 1.2);
  } else if (farmLvl === 6) {
    farm6(600, 330, 1.2);
    farm6(630, 330, 1.2);
    farm6(660, 330, 1.2);
    farm6(690, 330, 1.2);
  }

  //draws the base according to the base level
  if (baseLvl === 1) {
    base1(530, 370, 1);
    base1(500, 340, 0.6);
    base1(470, 380, 0.6);
    base1(590, 360, 0.6);
  } else if (baseLvl === 2) {
    base2(530, 350, 1.2);
    base2(570, 340, 0.7);
    base2(470, 370, 0.7);
    base2(580, 380, 0.7);
    base2(600, 360, 0.7);
  } else if (baseLvl === 3) {
    base3(530, 350, 0.7);
    base3(570, 360, 0.5);
    base3(470, 370, 0.5);
    base3(500, 340, 0.5);
    base3(550, 345, 0.5);
  } else if (baseLvl === 4) {
    base4(530, 350, 0.7);
    base4(460, 350, 0.5);
    base4(490, 380, 0.5);
    base4(590, 370, 0.5);
    base4(610, 360, 0.5);
  } else if (baseLvl === 5) {
    base5(480, 355, 0.4);
    base5(490, 385, 0.4);
    base5(530, 365, 0.5);
    base5(590, 375, 0.4);
  } else if (baseLvl === 6) {
    base6(535, 320, 0.6);
    base6(470, 320, 0.4);
    base6(570, 350, 0.4);
    base6(510, 360, 0.4);
  } else if (baseLvl === 7) {
    base7(500, 365, 1);
    base7(570, 355, 1);
    base7capital(535, 295, 2);
    base7(470, 390, 1);
    base7(610, 380, 1);
  }

  //draws the mine according to the mine level
  if (mineLvl === 1) {
    mine1(280, 450, 1);
    mine1(380, 455, 1);
    mine1(340, 470, 1);
    mine1(420, 475, 1);

    //swinging controls
    if (mine1Swing === true) {
      mine1Rot -= 10;
    } else {
      mine1Rot += 2;
    }
    if (mine1Rot < -50) {
      mine1Swing = false;
    } else if (mine1Rot > 100) {
      mine1Swing = true;
    }
  } else if (mineLvl === 2) {
    mine2(280, 440, 1);
    mine2(380, 435, 1);
    mine2(340, 450, 1);
    mine2(420, 455, 1);

    //swinging controls
    if (mine2Swing === true) {
      mine2Rot -= 10;
    } else {
      mine2Rot += 2;
    }
    if (mine2Rot < -50) {
      mine2Swing = false;
    } else if (mine2Rot > 0) {
      mine2Swing = true;
    }

  } else if (mineLvl === 3) {

    mine3(350, 430, 1);
    mine3(270, 460, 1);
    mine3(410, 470, 1);
    mine3(340, 465, 1);
  } else if (mineLvl === 4) {
    mine4(400, 450, 1);
    mine4(350, 420, 1);
    mine4(280, 430, 1);
    mine4(320, 440, 1);
  } else if (mineLvl === 5) {

    mine5(350, 440, 0.5);
    mine5(280, 450, 0.5);
    mine5(420, 470, 0.5);
    //rotational controls for the excavator
    if (mine6Dig === true) {
      mine6Rot -= 1;
    } else {
      mine6Rot += 1;
    }
    if (mine6Rot < -30) {
      mine6Dig = false;
    } else if (mine6Rot > 30) {
      mine6Dig = true;
    }
  } else if (mineLvl === 6) {

    mine6(280, 440, 1);
    mine6(410, 450, 1);
    mine6(340, 420, 1);


    //the rotational control for the motor and drill
    if (oilDown === true) {
      oilRot -= 0.4;
    } else {
      oilRot += 0.4;
    }

    if (oilRot < -30) {
      oilDown = false;
    } else if (oilRot > 30) {
      oilDown = true;
    }
    oil2Rot -= 1.2;
    if (oil2Rot < -360) {
      oil2Rot = 0;
    }

  } else if (mineLvl === 7) {

    mine7(310, 180, 1);
    mine7(410, 200, 1);
  }



  /////////////////////////////////////////////////ITEM BAR////////////////////////////////////////////////
  stroke(184, 116, 0);
  strokeWeight(4);
  fill(204, 136, 0);
  quad(-10, 450, 100, 450, 200, 600, -10, 600);
  rect(-5, 555, 999, 999);
  textSize(25);
  textAlign(LEFT);
  foodIcon(200, 580, 2.5);
  fill(0);
  noStroke();
  text(floor(food), 230, 590);

  powerIcon(380, 575, 1);
  fill(0);
  noStroke();
  text(floor(energy), 390, 590);

  materialIcon(560, 575, 1);
  fill(0);
  noStroke();
  text(floor(material), 575, 590);

  personIcon(20, 575, 1.5);
  fill(0);
  noStroke();
  text(population, 38, 590);
  population = floor(population);

  threatIcon(20, 470, 1.5);
  noStroke();
  fill(0);
  text(floor((threatAmount * 10)) / 10 + "%", 40, 485);
  defenceIcon(20, 525, 1.2);

  noStroke();
  fill(0);
  text(floor(defence), 40, 530);


  /////////////////////////////////////////BUTTONS FOR THE ISLAND//////////////////////////////////////////


  //guards
  fill(100);
  noStroke();
  rect(500, 400, 50, 20, 5);
  textSize(20);
  fill(0);
  textAlign(CENTER);
  text(guards, 525, 417);

  //miners
  islandButtonGraphics(355, 490, 1, miners);
  //button detection for mine button
  if (trueMouseY > 480 && trueMouseY < 500 && mouseIsPressed && mouseOff === true && gettingAttacked === false && tutorial === false) {
    //adds people to the mine
    if (trueMouseX > 315 && trueMouseX < 335 && guards > 0) {
      if (moveAmount > guards) {
        miners += guards;
        guards = 0;
      } else {
        guards -= moveAmount;
        miners += moveAmount;
      }
    }

    //removes people from mine and puts them back into the base
    if (trueMouseX > 375 && trueMouseX < 395 && miners > 0) {
      if (moveAmount > miners) {
        guards += miners;
        miners = 0;
      } else {
        guards += moveAmount;
        miners -= moveAmount;
      }
    }
  }




  //farmers
  islandButtonGraphics(670, 370, 1, farmers);
  //button detection for farm button
  if (trueMouseY > 360 && trueMouseY < 380 && mouseIsPressed && mouseOff === true && gettingAttacked === false && tutorial === false) {
    //adds people to the farm
    if (trueMouseX > 630 && trueMouseX < 650 && guards > 0) {
      if (moveAmount > guards) {
        farmers += guards;
        guards = 0;
      } else {
        guards -= moveAmount;
        farmers += moveAmount;
      }
    }

    //removes people from farm and puts them back into the base
    if (trueMouseX > 690 && trueMouseX < 710 && farmers > 0) {
      if (moveAmount > farmers) {
        guards += farmers;
        farmers = 0;
      } else {
        guards += moveAmount;
        farmers -= moveAmount;
      }
    }
  }





  //electricians (power plant)
  if (powerplantLvl > 0) {
    islandButtonGraphics(360, 340, 1, electricians);
    //button detection for power plant button
    if (trueMouseY > 330 && trueMouseY < 350 && mouseIsPressed && mouseOff === true && gettingAttacked === false && tutorial === false) {
      //adds people to the power plant
      if (trueMouseX > 320 && trueMouseX < 340 && guards > 0) {
        if (moveAmount > guards) {
          electricians += guards;
          guards = 0;
        } else {




          guards -= moveAmount;
          electricians += moveAmount;
        }
      }

      //removes people from power plant and puts them back into the base
      if (trueMouseX > 380 && trueMouseX < 400 && electricians > 0) {
        if (moveAmount > electricians) {
          guards += electricians;
          electricians = 0;
        } else {
          guards += moveAmount;
          electricians -= moveAmount;
        }
      }
    }
  }












  ////////////////////////////////////////////STATS FOR THE GAME///////////////////////////////////////////


  //what happens each cycle
  if (timer < 0 && paused === false) {
    food += foodPerCycle;
    material += materialPerCycle;
    energy += powerPerCycle;
    threat += (threat / random(8, 12)) / difficultyMultiplier;
    timer = 300;
    //takes away food depending on how many people there are
    food -= population / 2;

    //slowly kills people if the max population is larger than the population cap
    if (population > populationMax) {
      miners -= floor((population - populationMax) / 8);
      farmers -= floor((population - populationMax) / 8);
      guards -= floor((population - populationMax) / 8);
      electricians -= floor((population - populationMax) / 8);
      if (miners < 0) {
        miners = 0;
      }
      if (farmers < 0) {
        farmers = 0;
      }
      if (guards < 0) {
        guards = 0;
      }
      if (electricians < 0) {
        electricians = 0;
      }
    }


    if (food > 0) {
      //makes more people if you have enough food
      if (food > population / 4 && population < populationMax) {
        if (population + (floor(food / 16)) + 1 <= populationMax) {
          population += (floor(food / 16)) + 1;
          guards += (floor(food / 16)) + 1;
        } else {
          guards += (populationMax - population)
          population = populationMax;
        }

      }
    } else {
      //people will starve accordingly, starting from electricians, miners, guards, and finally farmers
      starving = floor(abs(food)) + 1;
      food = 0;
      if (starving > 0) {
        if (electricians >= starving) {
          electricians -= starving;
          starving = 0;
        } else {
          starving -= electricians;
          electricians = 0;
        }

        if (miners >= starving) {
          miners -= starving;
          starving = 0;
        } else {
          starving -= electricians;
          electricians = 0;
        }

        if (guards >= starving) {
          guards -= starving;
          starving = 0;
        } else {
          starving -= guards;
          guards = 0;
        }

        if (farmers >= starving) {
          farmers -= starving;
          starving = 0;
        } else {
          starving -= farmers;
          farmers = 0;
        }

      }
    }
    //calculates whether you will be attacked or not
    attackChance = random(0, 100);
    if (attackChance <= threatAmount) {
      paused = true;
      gettingAttacked = true;

    }
  }

  //counts down the timer if your game is not paused or if your not on the tutorial
  if (paused === false && tutorial === false) {
    timer--;
  }


  //if you get attacked
  if (gettingAttacked === true) {
    paused = true;
    noStroke();
    fill(0, 0, 0, 100);
    rect(0, 0, 999, 999);
    fill(82);
    stroke(50);
    strokeWeight(5);
    rect(50, 50, 700, 500, 50);
    textAlign(CENTER);
    textSize(40);
    fill(255, 0, 0);
    text("YOU ARE GETTING ATTACKED!", 400, 150);
    textSize(25);
    text("Your Army Strength: " + floor(defence), 220, 220);
    text("Enemy Army Strength: " + floor(threat), 220, 320);

    //button graphics
    fill(100);
    noStroke();
    rect(200, 400, 150, 140, 10);
    rect(450, 400, 150, 140, 10);
    fill(255);
    text("DEFEND", 275, 425);
    text("RUN", 525, 425);
    textSize(15);
    textAlign(LEFT);
    text("Fight the enemy army. You will lose people depending on how strong your defence is.", 202, 435, 160, 1000);
    textSize(12.5);
    text("Flee from the enemy. No lives will be lost, however, all of your buildings will be downgraded by one. (Unless your buildings are already at the lowest level)", 452, 435, 155, 1000);


    //button detection and function


    if (mouseIsPressed && trueMouseY > 400 && trueMouseY < 540 && defendConfirm === false && runConfirm === false && tutorial === false) {
      //if you press defend
      if (trueMouseX > 200 && trueMouseX < 350) {
        defendConfirm = true;
      } //if you press run
      else if (trueMouseX > 450 && trueMouseX < 600) {
        runConfirm = true;

      }


    }
    if (defendConfirm === true) {
      //graphics
      noStroke();
      fill(160);
      rect(300, 250, 200, 100, 5);
      textAlign(CENTER);
      fill(0);
      textSize(18);
      text("Do you want to defend?", 400, 300);
      fill(80);
      rect(320, 320, 40, 20, 5);
      rect(440, 320, 40, 20, 5);
      fill(255);
      noStroke();
      textSize(15);
      text("Yes", 340, 335);
      text("No", 460, 335);
      //button collisions
      if (mouseIsPressed && trueMouseY > 320 && trueMouseY < 340) {
        //if yes is pressed
        if (trueMouseX > 320 && trueMouseX < 360) {
          mouseOff = false;
          killed = floor(threat / (defence / threat))

          if (guards >= killed) {
            guards -= killed;
            killed = 0;
          } else {
            killed -= guards;
            guards = 0;
          }

          if (miners >= killed * 2) {
            miners -= killed * 2;
            killed = 0;
          } else {
            killed -= miners / 2;
            miners = 0;
          }

          if (farmers >= killed * 3) {
            farmers -= killed * 3;
            killed = 0;
          } else {
            killed -= farmers / 3;
            farmers = 0;
          }

          if (electricians >= killed * 4) {
            electricians -= killed * 4;
            killed = 0;
          } else {
            electricians = 0;
          }
          gettingAttacked = false;
          paused = false;
          defendConfirm = false;
        }
        //if no is pressed
        if (trueMouseX > 440 && trueMouseX < 480 && tutorial === false) {
          defendConfirm = false;
        }

      }

    }
    if (runConfirm === true) {
      mouseOff = true;
      //graphics
      noStroke();
      fill(160);
      rect(300, 250, 200, 100, 5);
      textAlign(CENTER);
      fill(0);
      textSize(20);
      text("Do you want to run?", 400, 300);
      fill(80);
      rect(320, 320, 40, 20, 5);
      rect(440, 320, 40, 20, 5);
      fill(255);
      noStroke();
      textSize(15);
      text("Yes", 340, 335);
      text("No", 460, 335);
      //button collisions
      if (mouseIsPressed && trueMouseY > 320 && trueMouseY < 340) {
        //if yes is pressed
        if (trueMouseX > 320 && trueMouseX < 360) {
          if (baseLvl > 1) {
            baseLvl--;
          }
          if (farmLvl > 1) {
            farmLvl--;
          }
          if (mineLvl > 1) {
            mineLvl--;
          }
          if (powerplantLvl > 0) {
            powerplantLvl--;
          }
          gettingAttacked = false;
          paused = false;
          runConfirm = false;
        }
        //if no is pressed
        if (trueMouseX > 440 && trueMouseX < 480 && tutorial === false) {
          runConfirm = false;
        }

      }

    }


  }







  foodPerCycle = farmers * foodBoost;
  materialPerCycle = miners * materialBoost;
  powerPerCycle = electricians * powerBoost;
  defence = guards * defenceBoost;

  //the boosts for each building
  if (baseLvl === 1) {
    defenceBoost = 1 * difficultyMultiplier;
    populationMax = 100 * difficultyMultiplier;
  } else if (baseLvl === 2) {
    defenceBoost = 2 * difficultyMultiplier;
    populationMax = 500 * difficultyMultiplier;
  } else if (baseLvl === 3) {
    defenceBoost = 5 * difficultyMultiplier;
    populationMax = 2000 * difficultyMultiplier;
  } else if (baseLvl === 4) {
    defenceBoost = 8 * difficultyMultiplier;
    populationMax = 6000 * difficultyMultiplier;
  } else if (baseLvl === 5) {
    defenceBoost = 20 * difficultyMultiplier;
    populationMax = 10000 * difficultyMultiplier;
  } else if (baseLvl === 6) {
    defenceBoost = 50 * difficultyMultiplier;
    populationMax = 15000 * difficultyMultiplier;
  } else if (baseLvl === 7) {
    defenceBoost = 200 * difficultyMultiplier;
    populationMax = 40000 * difficultyMultiplier;
  }

  if (farmLvl === 1) {
    foodBoost = 1 * difficultyMultiplier;
  } else if (farmLvl === 2) {
    foodBoost = 2 * difficultyMultiplier;
  } else if (farmLvl === 3) {
    foodBoost = 7 * difficultyMultiplier;
  } else if (farmLvl === 4) {
    foodBoost = 25 * difficultyMultiplier;
  } else if (farmLvl === 5) {
    foodBoost = 75 * difficultyMultiplier;
  } else if (farmLvl === 6) {
    foodBoost = 200 * difficultyMultiplier;
  }

  if (mineLvl === 1) {
    materialBoost = 1 * difficultyMultiplier;
  } else if (mineLvl === 2) {
    materialBoost = 2 * difficultyMultiplier;
  } else if (mineLvl === 3) {
    materialBoost = 6 * difficultyMultiplier;
  } else if (mineLvl === 4) {
    materialBoost = 10 * difficultyMultiplier;
  } else if (mineLvl === 5) {
    materialBoost = 30 * difficultyMultiplier;
  } else if (mineLvl === 6) {
    materialBoost = 80 * difficultyMultiplier;
  } else if (mineLvl === 7) {
    materialBoost = 200 * difficultyMultiplier;
  }

  if (powerplantLvl === 1) {
    powerBoost = 1 * difficultyMultiplier;
  } else if (powerplantLvl === 2) {
    powerBoost = 3 * difficultyMultiplier;
  } else if (powerplantLvl === 3) {
    powerBoost = 20 * difficultyMultiplier;
  } else if (powerplantLvl === 4) {
    powerBoost = 70 * difficultyMultiplier;
  } else if (powerplantLvl === 5) {
    powerBoost = 200 * difficultyMultiplier;
  }

  //calculations for threat/population/amount of people moved per click
  if ((threat / defence) * 50 < 100) {
    threatAmount = (threat / defence) * 50;
  } else {
    threatAmount = 100;
  }
  population = guards + farmers + miners + electricians;
  moveAmount = floor(population / 20) + 1;

  //upgrade panel button
  fill(11, 214, 0);
  stroke(100);
  strokeWeight(2);
  rect(735, 25, 40, 40, 5);
  fill(220);
  beginShape();
  vertex(755, 30);
  vertex(742, 40);
  vertex(750, 40);
  vertex(750, 55);
  vertex(760, 55);
  vertex(760, 40);
  vertex(768, 40);
  endShape(CLOSE);
  if (mouseIsPressed && gettingAttacked === false && trueMouseX > 735 && trueMouseX < 775 && trueMouseY > 25 && trueMouseY < 65 && tutorial === false) {
    display = "UPGRADE";
  }

  //menu button
  fill(120);
  stroke(150);
  strokeWeight(4);
  rect(25, 25, 40, 40, 5);
  stroke(80);
  line(34, 36, 56, 36);
  line(34, 45, 56, 45);
  line(34, 54, 56, 54);

  if (mouseIsPressed && gettingAttacked === false && trueMouseX > 25 && trueMouseX < 65 && trueMouseY > 25 && trueMouseY < 65 && tutorial === false) {
    display = "MENU"
  }







  //win/lose stuff
  if (population === 0 && tutorial === false) {
    lose = true;
  }
  if (lose === true) {
    display = "LOSE";
  }
  if (baseLvl === 7 && won === false) {
    won = true;
    display = "WIN";
  }



  pop();


};

var difficultySelect = function() {
  background(155);
  stroke(100);
  strokeWeight(5);
  fill(43, 188, 255);
  rect(200, 200, 400, 200);
  textAlign(CENTER);
  textSize(30);
  fill(0);
  noStroke();
  text("Select Your Difficulty", 400, 250);
  fill(255);
  rect(240, 300, 80, 40, 5);
  rect(360, 300, 80, 40, 5);
  rect(480, 300, 80, 40, 5);
  fill(0);
  textSize(20);
  text("EASY", 280, 327);
  text("MEDIUM", 400, 327);
  text("HARD", 520, 327);
  if (mouseIsPressed && trueMouseY > 300 && trueMouseY < 340) {
    //select easy  
    if (trueMouseX > 240 && trueMouseX < 320) {
      difficulty = "EASY";
      display = "GAME";
      mouseOff = false;
    }
    //select medium
    if (trueMouseX > 360 && trueMouseX < 440) {
      difficulty = "MEDIUM";
      display = "GAME";
      mouseOff = false;
    }
    //select hard
    if (trueMouseX > 480 && trueMouseX < 560) {
      difficulty = "HARD";
      display = "GAME";
      mouseOff = false;
    }










  }
};

////////////////////////////DRAW FUNCTION (DRAWS EVERYTHING THAT NEEDS TO BE DRAWN///////////////////////////

function draw() {

  //sets the true MouseX
  trueMouseX = (mouseX - displayCut) / scaleMod;
  trueMouseY = mouseY / scaleMod;
  trueMouseX = constrain(trueMouseX, 0, 800);
  trueMouseY = constrain(trueMouseY, 0, 600);


  //keeps things from going into negatives
  if (energy < 0) {
    energy = 0;
  }
  if (material < 0) {
    material = 0;
  }

  push();
  translate(displayCut, 0);
  scale(scaleMod);

  //displays the correct scene
  if (display === "UPGRADE") {
    upgradeMenu();
  }
  if (display === "LOSE") {
    loseScreen();
  }
  if (display === "GAME") {
    game();
  }
  if (display === "MENU") {
    menu();
  }
  if (display === "WIN") {
    winScreen();
  }
  if (display === "DIFFICULTY") {
    difficultySelect();
  }





  /////////////////////////////////////////////////TUTORIAL/////////////////////////////////////////////////

  if (tutorial === true && display !== "MENU" && display !== "DIFFICULTY") {


    if (tutorialStep === 1) {
      dialogue = "Hello, welcome to Island Civilization. Let me show you around. Tap anywhere to continue. Right click to skip the tutorial";
      dialogueSize = 30;
      tboxX = 400;
      tboxY = 300;
      tboxSize = 0;
      if (mouseIsPressed && mouseOff === true) {
        mouseOff = false;
        tutorialStep = 2;
      }
    }

    if (tutorialStep === 2) {
      dialogue = "Click this plus button to take people from the base to the farm. If you do not have enough food, your people will starve. Click until you have 14 farmers.";
      dialogueSize = 30;
      tboxX = 640;
      tboxY = 370;
      tboxSize = 30;

      if (farmers >= 14) {
        tutorialStep = 3;
      }
      if (mouseIsPressed && trueMouseX > tboxX - (tboxSize / 2) && trueMouseX < tboxX + (tboxSize / 2) && trueMouseY > tboxY - (tboxSize / 2) && trueMouseY < tboxY + (tboxSize / 2) && mouseOff === true) {
        mouseOff = false;
        farmers++;
        guards--;
      }
    }

    if (tutorialStep === 3) {
      dialogue = "Click this plus button to take people from the base to the mine. Mines give material which is used for upgrading your buildings. Bring the rest of the guards at the base to the mine"
      dialogueSize = 30;
      tboxX = 325;
      tboxY = 490;
      tboxSize = 30;


      if (miners >= 6) {
        tutorialStep = 4;
      }


      //box detection 
      if (mouseIsPressed && trueMouseX > tboxX - (tboxSize / 2) && trueMouseX < tboxX + (tboxSize / 2) && trueMouseY > tboxY - (tboxSize / 2) && trueMouseY < tboxY + (tboxSize / 2) && mouseOff === true) {
        mouseOff = false;
        guards--;
        miners++;
      }

    }

    if (tutorialStep === 4) {
      dialogue = "Oh no! You've been attacked. This happens when you don't have enough people at the base to guard. Since we haven't upgraded any of our buildings, we should run. Click run";
      dialogueSize = 22;
      tboxX = 525;
      tboxY = 470;
      tboxSize = 150;
      gettingAttacked = true;
      if (mouseIsPressed && trueMouseX > tboxX - (tboxSize / 2) && trueMouseX < tboxX + (tboxSize / 2) && trueMouseY > tboxY - (tboxSize / 2) && trueMouseY < tboxY + (tboxSize / 2) && mouseOff === true) {
        runConfirm = true;
        mouseOff = false;
        tutorialStep = 5;
      }
    }

    if (tutorialStep === 5) {
      dialogue = "Click yes to confirm.";
      dialogeSize = 30;
      tboxX = 340;
      tboxY = 330;
      tboxSize = 40;

      if (runConfirm === false) {
        mouseOff = false;
        tutorialStep = 6;
      }
    }

    if (tutorialStep === 6) {
      dialogue = "When you're in the early stages of the game, you should keep running from threats until you upgrade anything because running decreases all of your building's levels by one unless they are at the minimum level. This is where you see the chances that you will be attacked. Click to continue";
      dialogueSize = 25;
      tboxX = 60;
      tboxY = 475;
      tboxSize = 40;

      //detection
      if (mouseIsPressed && mouseOff === true) {
        material += 200;
        mouseOff = false;
        tutorialStep = 7;
      }
    }

    if (tutorialStep === 7) {
      dialogue = "Here, I gave you some extra material. You now have enough to upgrade your base once. Click the upgrade button to go to the upgrade panel";
      dialogueSize = 30;
      tboxX = 755;
      tboxY = 45;
      tboxSize = 50;

      //button detection
      if (mouseIsPressed && trueMouseX > tboxX - (tboxSize / 2) && trueMouseX < tboxX + (tboxSize / 2) && trueMouseY > tboxY - (tboxSize / 2) && trueMouseY < tboxY + (tboxSize / 2) && mouseOff === true) {
        display = "UPGRADE";
        mouseOff = false;
        tutorialStep = 8;
      }
    }

    if (tutorialStep === 8) {
      dialogue = "This is the upgrade panel. Here you will find the cost of all the upgrades for your base, mine, farm, and power plant. Click to continue";
      dialogueSize = 19;
      tboxX = 0;
      tboxY = 0;
      tboxSize = 0;

      //detection
      if (mouseIsPressed) {
        tutorialStep = 9;
        mouseOff = false;
      }
    }

    if (tutorialStep === 9) {
      dialogue = "This is the button for upgrading your base. Upgrading it will increase your defence multiplier and your population cap. Click to continue";
      dialogueSize = 19;
      tboxX = 140;
      tboxY = 220;
      tboxSize = 100;
      //detection
      if (mouseIsPressed && mouseOff === true) {
        tutorialStep = 10;
        mouseOff = false;
      }
    }

    if (tutorialStep === 10) {
      dialogue = "This is the button for upgrading your mine. Upgrading it will increase your material multiplier. Click to continue";
      dialogueSize = 20;
      tboxX = 310;
      tboxY = 220;
      tboxSize = 100;
      //detection
      if (mouseIsPressed && mouseOff === true) {
        tutorialStep = 11;
        mouseOff = false;
      }
    }

    if (tutorialStep === 11) {
      dialogue = "This is the button for upgrading your farm. Upgrading it will increase your food multiplier. Click to continue";
      dialogueSize = 20;
      tboxX = 480;
      tboxY = 220;
      tboxSize = 100;
      //detection
      if (mouseIsPressed && mouseOff === true) {
        tutorialStep = 12;
        mouseOff = false;
      }
    }

    if (tutorialStep === 12) {
      dialogue = "This is the button for upgrading your power plant. Upgrading it will allow you to generate power and increase your energy multiplier. Click to continue";
      dialogueSize = 18;
      tboxX = 650;
      tboxY = 220;
      tboxSize = 100;
      //detection
      if (mouseIsPressed && mouseOff === true) {
        tutorialStep = 13;
        mouseOff = false;
      }
    }

    if (tutorialStep === 13) {
      dialogue = "You have enough materials to upgrade your base. Click here to upgrade it"
      dialogueSize = 25;
      tboxX = 140;
      tboxY = 220;
      tboxSize = 100;

      if (mouseIsPressed && trueMouseX > tboxX - (tboxSize / 2) && trueMouseX < tboxX + (tboxSize / 2) && trueMouseY > tboxY - (tboxSize / 2) && trueMouseY < tboxY + (tboxSize / 2) && mouseOff === true) {
        mouseOff = false;
        baseLvl++;
        material -= 200;
        tutorialStep = 14;
      }
    }

    if (tutorialStep === 14) {
      dialogue = "Well done. Lets head back to the map. Click here to go back";
      dialogueSize = 22;
      tboxX = 715;
      tboxY = 85;
      tboxSize = 40;
      if (mouseIsPressed && trueMouseX > tboxX - (tboxSize / 2) && trueMouseX < tboxX + (tboxSize / 2) && trueMouseY > tboxY - (tboxSize / 2) && trueMouseY < tboxY + (tboxSize / 2) && mouseOff === true) {
        mouseOff = false;
        display = "GAME";
        tutorialStep = 15;
      }
    }

    if (tutorialStep === 15) {
      dialogue = "Now that you have an upgraded base, your guards will be stronger. Since we don't need all the farmers, we should put them back to the base to defend against threats. Click this minus button to bring some farmers back to the base to defend. Bring back 4 farmers.";
      dialogueSize = 20;
      tboxX = 700;
      tboxY = 370;
      tboxSize = 30;
      if (guards >= 4) {
        tutorialStep = 16;
      }

      if (mouseIsPressed && trueMouseX > tboxX - (tboxSize / 2) && trueMouseX < tboxX + (tboxSize / 2) && trueMouseY > tboxY - (tboxSize / 2) && trueMouseY < tboxY + (tboxSize / 2) && mouseOff === true) {
        mouseOff = false;
        farmers--;
        guards++;
      }
    }

    if (tutorialStep === 16) {
      dialogue = "Good job. See that bringing people back to defend also decreases the chance that you will be attacked. Click to continue";
      dialogueSize = 20;
      tboxX = 70;
      tboxY = 475;
      tboxSize = 60;
      if (mouseIsPressed && mouseOff === true) {
        mouseOff = false;
        tutorialStep = 17;
      }
    }

    if (tutorialStep === 17) {
      dialogue = "You can also see how strong your defence is here";
      dialogueSize = 30;
      tboxX = 65;
      tboxY = 520;
      tboxSize = 60;
      if (mouseIsPressed && mouseOff === true) {
        mouseOff = false;
        tutorialStep = 18;
      }
    }

    if (tutorialStep === 18) {
      dialogue = "Going left to right, you can see your population, food, energy, and materials.";
      dialogueSize = 30;
      tboxX = 400;
      tboxY = 950;
      tboxSize = 800;
      if (mouseIsPressed && mouseOff === true) {
        food += 50;
        material += 150;

        mouseOff = false;
        tutorialStep = 19;
      }
    }

    if (tutorialStep === 19) {
      dialogue = "Congradulations, you have completed the tutorial. I have given you some extra food and materials to keep going. The goal of the game is to build the highest leveled base. You may still play after you do that. Good luck and have fun!";
      dialogueSize = 20;
      tboxX = 0;
      tboxY = 0;
      tboxSize = 0;
      if (mouseIsPressed && mouseOff === true) {
        mouseOff = false;
        tutorial = false;
      }
    }

    if (mouseIsPressed && mouseButton === RIGHT) {
      tutorial = false;
      material = 350;
      food = 50;
    }

    //graphics for the tutorial
    rectMode(CENTER);
    noFill();
    stroke(0, 0, 0, 100);
    strokeWeight(1000);
    rect(tboxX, tboxY, tboxSize + 1000, tboxSize + 1000);
    rectMode(CORNER);
    fill(255);
    stroke(0);
    strokeWeight(2);
    textSize(dialogueSize);
    textAlign(CENTER);
    text(dialogue, 100, 20, 600, 1000);
  }

  pop();

  //a clicking function
  if (mouseIsPressed) {
    mouseOff = false;
  } else {
    mouseOff = true;
  }

  //super easy
  if (difficulty === "EASY") {
    difficultyMultiplier = 2;
  }
  //slightly difficult
  if (difficulty === "MEDIUM") {
    difficultyMultiplier = 1;
  }
  //insanely hard, if you beat this, I will be amazed
  if (difficulty === "HARD") {
    difficultyMultiplier = 0.5;
  }

  //makes sure you don't have fractions of units
  farmers = floor(farmers);
  guards = floor(guards);
  miners = floor(miners);
  electricians = floor(electricians);

  push();
  rectMode(CORNER);
  noStroke();
  fill(28);
  rect(0, 0, displayCut, height);
  rect(width - displayCut, 0, displayCut, height);
  pop();
}